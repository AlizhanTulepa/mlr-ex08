export const POLICY = Object.freeze({timeZone:'Europe/Prague',opensAt:'07:00',closesAt:'22:00',slotMinutes:30,minDurationMinutes:30,maxDurationMinutes:180,demo:true});
export class ApiError extends Error {
  constructor(status, code, message) { super(message); this.status=status; this.code=code; }
}
export function fail(status, code, message) { throw new ApiError(status,code,message); }
const formatter = new Intl.DateTimeFormat('en-CA',{timeZone:POLICY.timeZone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
export function localParts(ms) {
  const p=Object.fromEntries(formatter.formatToParts(new Date(ms)).filter(p=>p.type!=='literal').map(p=>[p.type,p.value]));
  return {date:`${p.year}-${p.month}-${p.day}`,hour:Number(p.hour),minute:Number(p.minute),second:Number(p.second)};
}
export function validateDate(value) {
  if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value)||Number(value.slice(0,4))<1000) fail(400,'INVALID_DATE','date must be a real calendar date YYYY-MM-DD (year 1000–9999)');
  const d=new Date(`${value}T00:00:00Z`);
  if(!Number.isFinite(+d)||d.toISOString().slice(0,10)!==value) fail(400,'INVALID_DATE','date must be a real calendar date YYYY-MM-DD');
  return value;
}
export function parseTimestamp(value, field='timestamp') {
  const m=typeof value==='string'&&value.match(/^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2})(?::(\d{2})(\.\d{1,3})?)?(Z|([+-])(\d{2}):(\d{2}))$/);
  if(!m) fail(400,'INVALID_TIMESTAMP',`${field} must be ISO 8601 with an explicit offset, e.g. 2027-01-05T09:00:00+01:00`);
  validateDate(m[1]);
  if(+m[2]>23||+m[3]>59||+(m[4]||0)>59||+(m[8]||0)>14||+(m[9]||0)>59||(+m[8]===14&&+m[9]!==0)) fail(400,'INVALID_TIMESTAMP',`${field} contains an invalid clock time or UTC offset`);
  const normalized=`${m[1]}T${m[2]}:${m[3]}:${m[4]||'00'}${m[5]||''}${m[6]}`;
  const ms=Date.parse(normalized);
  if(!Number.isFinite(ms)) fail(400,'INVALID_TIMESTAMP',`${field} is invalid`);
  return ms;
}
export function durationMinutes(value=30) {
  const n=typeof value==='string'&&/^\d+$/.test(value)?Number(value):value;
  if(!Number.isInteger(n)||n<30||n>180||n%30!==0) fail(400,'INVALID_DURATION','durationMinutes must be 30–180 in 30-minute increments');
  return n;
}
export function validateInterval(start,end,now,{booking=true}={}) {
  const a=parseTimestamp(start,'start'), b=parseTimestamp(end,'end');
  if(b<=a) fail(400,'INVALID_INTERVAL','end must be after start');
  if(booking) {
    if(a<now) fail(400,'PAST_BOOKING','Bookings cannot start in the past');
    durationMinutes((b-a)/60000);
    const x=localParts(a),y=localParts(b);
    if(a%1000||b%1000||x.second||y.second||x.minute%30||y.minute%30) fail(400,'INVALID_ALIGNMENT','Booking times must align to 30-minute boundaries in Europe/Prague');
    if(x.date!==y.date||x.hour<7||y.hour>22||(y.hour===22&&y.minute!==0)) fail(400,'OUTSIDE_OPEN_HOURS','Demo opening hours are 07:00–22:00 Europe/Prague on one calendar day');
  }
  return {start:a,end:b};
}
// Convert Prague wall time using Intl's IANA timezone rules, not the host timezone.
// Availability only generates 07:00–22:00, so DST's missing/duplicate 02:00 never occurs.
export function pragueTimestamp(date,minutes) {
  validateDate(date);
  const [y,m,d]=date.split('-').map(Number);
  const wall=Date.UTC(y,m-1,d,Math.floor(minutes/60),minutes%60);
  let instant=wall;
  for(let i=0;i<3;i++) {
    const p=localParts(instant),[yy,mm,dd]=p.date.split('-').map(Number);
    instant += wall-Date.UTC(yy,mm-1,dd,p.hour,p.minute,p.second);
  }
  const offset=(wall-instant)/60000, sign=offset<0?'-':'+';
  const pad=n=>String(n).padStart(2,'0');
  return `${date}T${pad(Math.floor(minutes/60))}:${pad(minutes%60)}:00${sign}${pad(Math.floor(Math.abs(offset)/60))}:${pad(Math.abs(offset)%60)}`;
}
