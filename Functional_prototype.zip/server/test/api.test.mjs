import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp,rm,writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp } from '../app.mjs';
import { createService } from '../service.mjs';
import { pragueTimestamp,parseTimestamp } from '../time.mjs';
const NOW='2027-01-05T05:00:00Z';
const booking=(start='2027-01-05T09:00:00+01:00',end='2027-01-05T10:00:00+01:00',resourceId='washer-1')=>({resourceId,start,end});
async function fixture(t,options={}) {
  const app=createApp({now:()=>NOW,...options});
  await new Promise(resolve=>app.server.listen(0,'127.0.0.1',resolve));
  t.after(()=>app.close());
  const base=`http://127.0.0.1:${app.server.address().port}`;
  const request=async(path,{method='GET',body,user,headers={}}={})=>{
    const res=await fetch(base+path,{method,headers:{...(body!==undefined?{'Content-Type':'application/json'}:{}),...(user?{'X-Demo-User':user}:{}),...headers},...(body!==undefined?{body:JSON.stringify(body)}:{})});
    return {status:res.status,headers:res.headers,data:res.status===204?null:await res.json()};
  };
  return {app,request,base};
}
test('fictional resources and demo business policy',async t=>{
  const {request}=await fixture(t),r=await request('/api/resources');
  assert.equal(r.status,200);assert.equal(r.data.resources.length,5);assert.equal(r.data.resources.filter(r=>r.type==='washer').length,3);
  assert.equal(r.data.policy.timeZone,'Europe/Prague');assert.equal(r.data.policy.demo,true);assert.ok(r.data.resources.every(r=>r.description.includes('Fictional')));
});
test('create, adjacent half-open overlap, identity and cancellation',async t=>{
  const {request}=await fixture(t);
  const a=await request('/api/bookings',{method:'POST',body:booking()});assert.equal(a.status,201);assert.equal(a.data.booking.userId,'xbatyra00');
  assert.equal((await request('/api/bookings',{method:'POST',body:booking('2027-01-05T09:30+01:00','2027-01-05T10:30+01:00')})).status,409);
  assert.equal((await request('/api/bookings',{method:'POST',body:booking('2027-01-05T10:00+01:00','2027-01-05T10:30+01:00')})).status,201);
  assert.equal((await request(`/api/bookings/${a.data.booking.id}`,{method:'DELETE',user:'other'})).status,403);
  assert.equal((await request('/api/bookings',{user:'other'})).data.bookings.length,0);
  assert.equal((await request('/api/bookings?scope=all',{user:'other'})).data.bookings.length,2);
  assert.equal((await request(`/api/bookings/${a.data.booking.id}`,{method:'DELETE'})).data.booking.status,'cancelled');
  assert.equal((await request(`/api/bookings/${a.data.booking.id}`,{method:'DELETE'})).status,200);
  assert.equal((await request('/api/bookings',{method:'POST',body:booking()})).status,201);
});
test('reschedule excludes itself, checks conflicts and preserves original after rejection',async t=>{
  const {request}=await fixture(t);
  const a=(await request('/api/bookings',{method:'POST',body:booking()})).data.booking;
  await request('/api/bookings',{method:'POST',body:booking('2027-01-05T11:00+01:00','2027-01-05T12:00+01:00')});
  assert.equal((await request(`/api/bookings/${a.id}`,{method:'PATCH',body:{start:a.start,end:a.end}})).status,200);
  assert.equal((await request(`/api/bookings/${a.id}`,{method:'PATCH',user:'other',body:{start:a.start,end:a.end}})).status,403);
  assert.equal((await request(`/api/bookings/${a.id}`,{method:'PATCH',body:{start:'2027-01-05T11:00+01:00',end:'2027-01-05T12:00+01:00'}})).status,409);
  assert.equal((await request('/api/bookings')).data.bookings.find(b=>b.id===a.id).start,a.start);
  await request(`/api/bookings/${a.id}`,{method:'DELETE'});
  assert.equal((await request(`/api/bookings/${a.id}`,{method:'PATCH',body:{start:a.start,end:a.end}})).status,409);
});
test('maintenance blocks bookings, bookings block maintenance; CRUD frees intervals',async t=>{
  const {request}=await fixture(t);
  const b=booking(),m=await request('/api/maintenance',{method:'POST',body:{...b,reason:'Demo service'}});assert.equal(m.status,201);
  assert.equal((await request('/api/bookings',{method:'POST',body:b})).status,409);
  assert.equal((await request('/api/maintenance',{method:'POST',body:{...b,reason:'Overlapping'}})).status,409);
  assert.equal((await request(`/api/maintenance/${m.data.maintenance.id}`,{method:'PATCH',body:{start:'2027-01-05T10:00+01:00',end:'2027-01-05T11:00+01:00'}})).status,200);
  assert.equal((await request('/api/bookings',{method:'POST',body:b})).status,201);
  assert.equal((await request('/api/maintenance',{method:'POST',body:{...b,reason:'Booking collision'}})).status,409);
  assert.equal((await request('/api/maintenance?resourceId=washer-1')).data.maintenance.length,1);
  assert.equal((await request(`/api/maintenance/${m.data.maintenance.id}`,{method:'DELETE'})).status,204);
  assert.equal((await request('/api/maintenance')).data.maintenance.length,0);
});
test('maintenance persists across HTTP server restart and removal restores booking availability',async t=>{
  const dir=await mkdtemp(join(tmpdir(),'dormitory-maintenance-')),dbPath=join(dir,'test.sqlite');
  let app;
  t.after(async()=>{await app?.close();await rm(dir,{recursive:true,force:true});});
  async function start() {
    app=createApp({dbPath,now:()=>NOW});
    await new Promise(resolve=>app.server.listen(0,'127.0.0.1',resolve));
    return `http://127.0.0.1:${app.server.address().port}/api`;
  }
  let base=await start();
  const post=(path,body)=>fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const created=await post('/maintenance',{...booking(),reason:'Persistence inspection'});
  assert.equal(created.status,201);
  const {maintenance}=await created.json();
  await app.close();app=null;
  base=await start();
  assert.deepEqual((await (await fetch(base+'/maintenance')).json()).maintenance,[maintenance]);
  const blocked=await post('/bookings',booking());
  assert.equal(blocked.status,409);assert.equal((await blocked.json()).error.code,'TIME_CONFLICT');
  const availability=()=>fetch(base+'/availability?date=2027-01-05&resourceId=washer-1').then(r=>r.json());
  const slot=data=>data.resources[0].slots.find(s=>s.start.includes('T09:00:'));
  assert.equal(slot(await availability()).reason,'maintenance');
  assert.equal((await fetch(`${base}/maintenance/${maintenance.id}`,{method:'DELETE'})).status,204);
  assert.equal(slot(await availability()).available,true);
  assert.equal((await post('/bookings',booking())).status,201);
});
test('availability per duration, bookings, maintenance and past slots',async t=>{
  const {request}=await fixture(t,{now:()=> '2027-01-05T07:15:00Z'});
  await request('/api/bookings',{method:'POST',body:booking()});
  await request('/api/maintenance',{method:'POST',body:{...booking('2027-01-05T10:00+01:00','2027-01-05T11:00+01:00'),reason:'Repair'}});
  const r=await request('/api/availability?date=2027-01-05&durationMinutes=60&resourceId=washer-1');assert.equal(r.status,200);
  const slots=r.data.resources[0].slots;assert.equal(slots.length,29);assert.equal(slots[0].reason,'past');
  assert.equal(slots.find(s=>s.start.includes('T09:00:')).reason,'booking');assert.equal(slots.find(s=>s.start.includes('T10:00:')).reason,'maintenance');
  assert.equal(slots.at(-1).end,'2027-01-05T22:00:00+01:00');
});
test('availability for rescheduling ignores only the caller’s own booking',async t=>{
  const {request}=await fixture(t);
  const mine=(await request('/api/bookings',{method:'POST',body:booking()})).data.booking;           // 09:00–10:00
  const other=(await request('/api/bookings',{method:'POST',user:'other',body:booking('2027-01-05T10:00+01:00','2027-01-05T11:00+01:00')})).data.booking;
  const slots=async(extra='',user)=>(await request(`/api/availability?date=2027-01-05&durationMinutes=90&resourceId=washer-1${extra}`,{user})).data.resources[0].slots;
  const at=(list,time)=>list.find(s=>s.start.includes(`T${time}:`));
  // Without exclusion both bookings block, as before.
  assert.equal(at(await slots(),'08:00').reason,'booking');
  const moving=await slots(`&excludeBookingId=${mine.id}`);
  assert.equal(at(moving,'08:00').available,true,'08:00–09:30 overlaps only the booking being moved');
  assert.equal(at(moving,'09:30').reason,'booking','09:30–11:00 also overlaps the other resident’s 10:00–11:00 booking');
  assert.equal(at(moving,'09:00').reason,'booking','09:00–10:30 also overlaps the other booking');
  assert.equal(at(moving,'07:00').available,true);
  // Exclusion is by booking id: the other booking still blocks, and maintenance still blocks.
  await request('/api/maintenance',{method:'POST',body:{...booking('2027-01-05T07:00+01:00','2027-01-05T07:30+01:00'),reason:'Repair'}});
  assert.equal(at(await slots(`&excludeBookingId=${mine.id}`),'07:00').reason,'maintenance');
  // Only the owner may exclude a booking; unknown and empty ids are rejected.
  const probe=extra=>request(`/api/availability?date=2027-01-05&resourceId=washer-1&excludeBookingId=${extra}`,{user:'other'});
  assert.equal((await probe(mine.id)).status,403);
  assert.equal((await probe('missing')).status,404);
  assert.equal((await probe('')).status,400);
  assert.equal((await request(`/api/availability?date=2027-01-05&excludeBookingId=${other.id}`,{user:'other'})).status,200);
  // The slot list agrees with the server's final decision when saving.
  assert.equal((await request(`/api/bookings/${mine.id}`,{method:'PATCH',body:{start:'2027-01-05T09:30+01:00',end:'2027-01-05T11:00+01:00'}})).status,409);
  assert.equal((await request(`/api/bookings/${mine.id}`,{method:'PATCH',body:{start:'2027-01-05T08:00+01:00',end:'2027-01-05T09:30+01:00'}})).status,200);
});
test('Europe/Prague DST calendar uses real dates and not process timezone',async t=>{
  assert.equal(pragueTimestamp('2027-03-28',420),'2027-03-28T07:00:00+02:00');
  assert.equal(pragueTimestamp('2027-10-31',420),'2027-10-31T07:00:00+01:00');
  const {request}=await fixture(t);
  for(const [date,offset] of [['2027-03-28','+02:00'],['2027-10-31','+01:00']]) {
    const r=await request(`/api/availability?date=${date}&resourceId=washer-1`);assert.equal(r.data.resources[0].slots.length,30);assert.ok(r.data.resources[0].slots.every(s=>s.start.endsWith(offset)));
  }
  // Same absolute instant: 06:00 UTC is 07:00 Prague in winter.
  assert.equal((await request('/api/bookings',{method:'POST',body:booking('2027-01-05T06:00Z','2027-01-05T06:30Z')})).status,201);
});
test('invalid timestamps, dates, bounds, body and missing resources',async t=>{
  const {request,base}=await fixture(t);
  const bad=[booking('2027-01-05T09:00','2027-01-05T10:00'),booking('2027-02-30T09:00Z','2027-02-30T10:00Z'),booking('2027-01-05T25:00Z','2027-01-05T26:00Z'),booking('2027-01-05T09:00+15:00','2027-01-05T10:00+15:00'),booking('2027-01-04T09:00Z','2027-01-04T10:00Z'),booking('2027-01-05T06:30+01:00','2027-01-05T07:00+01:00'),booking('2027-01-05T21:30+01:00','2027-01-05T22:30+01:00'),booking('2027-01-05T09:15+01:00','2027-01-05T10:15+01:00'),booking('2027-01-05T09:00:00.001+01:00','2027-01-05T10:00:00.001+01:00'),booking('2027-01-05T09:00+01:00','2027-01-05T13:00+01:00'),booking('2027-01-05T10:00+01:00','2027-01-05T09:00+01:00'),{},[],null,{...booking(),seats:2},{...booking(),resourceId:12}];
  for(const body of bad) {const r=await request('/api/bookings',{method:'POST',body});assert.equal(r.status,400,JSON.stringify(body));assert.equal(typeof r.data.error.code,'string');}
  for(const q of ['date=2027-02-30','date=2027-1-5','date=2027-01-05&durationMinutes=31','date=2027-01-05&durationMinutes=','date=2027-01-05&durationMinutes=210','']) assert.equal((await request(`/api/availability?${q}`)).status,400,q);
  assert.equal((await request('/api/bookings',{method:'POST',body:{...booking(),resourceId:'none'}})).status,404);
  assert.equal((await request('/api/bookings/missing',{method:'DELETE'})).status,404);
  assert.equal((await request('/api/bookings',{user:'invalid user'})).status,400);
  assert.equal((await request('/api/bookings?scope=invalid')).status,400);
  const malformed=await fetch(base+'/api/bookings',{method:'POST',headers:{'Content-Type':'application/json'},body:'{'});assert.equal(malformed.status,400);
  const oversized=await fetch(base+'/api/bookings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({x:'a'.repeat(17000)})});assert.equal(oversized.status,413);
  assert.equal((await fetch(base+'/api/bookings',{method:'POST',body:'{}'})).status,415);
  assert.throws(()=>parseTimestamp('2027-01-05T09:00+14:01'));
});
test('actual occupancy is separate from future reservations, checkin/checkout idempotency',async t=>{
  let now=NOW;const {request}=await fixture(t,{now:()=>now});
  const future=(await request('/api/bookings',{method:'POST',body:booking()})).data.booking;
  assert.equal((await request('/api/usage?active=true')).data.usage.length,0);
  assert.equal((await request('/api/usage/checkin',{method:'POST',body:{resourceId:'washer-1',bookingId:future.id}})).status,409);
  const use=await request('/api/usage/checkin',{method:'POST',body:{resourceId:'washer-1'}});assert.equal(use.status,201);
  assert.equal((await request('/api/usage/checkin',{method:'POST',body:{resourceId:'washer-1'}})).status,409);
  assert.equal((await request('/api/usage?active=true')).data.usage.length,1);
  const availability=await request('/api/availability?date=2027-01-05&resourceId=washer-1');assert.equal(availability.data.resources[0].slots.find(s=>s.start.includes('T08:00:')).available,true);
  assert.equal((await request(`/api/usage/${use.data.usage.id}/checkout`,{method:'POST'})).status,200);
  assert.equal((await request(`/api/usage/${use.data.usage.id}/checkout`,{method:'POST'})).status,200);
  assert.equal((await request('/api/usage?active=true')).data.usage.length,0);
  now='2027-01-05T08:15:00Z';
  assert.equal((await request('/api/usage/checkin',{method:'POST',user:'other',body:{resourceId:'washer-1',bookingId:future.id}})).status,403);
  assert.equal((await request('/api/usage/checkin',{method:'POST',body:{resourceId:'washer-1',bookingId:future.id}})).status,201);
  assert.equal((await request(`/api/bookings/${future.id}`,{method:'DELETE'})).status,409);
});
test('maintenance prevents current check-in, but does not invent occupancy',async t=>{
  const {request}=await fixture(t);
  await request('/api/maintenance',{method:'POST',body:{...booking('2027-01-05T04:00Z','2027-01-05T06:00Z'),reason:'Offline'}});
  assert.equal((await request('/api/usage/checkin',{method:'POST',body:{resourceId:'washer-1'}})).status,409);
  assert.equal((await request('/api/usage?active=true')).data.usage.length,0);
});
test('concurrent create attempts produce exactly one booking',async t=>{
  const {request}=await fixture(t);
  const results=await Promise.all(Array.from({length:8},()=>request('/api/bookings',{method:'POST',body:booking()})));
  assert.equal(results.filter(r=>r.status===201).length,1);assert.equal(results.filter(r=>r.status===409).length,7);
});
test('SQLite persists across service restart and independent connections share conflicts',async()=>{
  const dir=await mkdtemp(join(tmpdir(),'dormitory-api-')),path=join(dir,'test.sqlite');
  let a,b;
  try {
    a=createService({dbPath:path,now:()=>NOW});a.createBooking(booking(),'xbatyra00');a.close();a=null;
    b=createService({dbPath:path,now:()=>NOW});assert.equal(b.bookings('xbatyra00').bookings.length,1);
    a=createService({dbPath:path,now:()=>NOW});assert.throws(()=>a.createBooking(booking(),'other'),e=>e.status===409);
  } finally {a?.close();b?.close();assert.ok(dir.startsWith(join(tmpdir(),'dormitory-api-')));await rm(dir,{recursive:true,force:true});}
});
test('Prague date boundary and exact opening/closing limits',async t=>{
  const {request}=await fixture(t,{now:()=> '2027-01-04T23:30:00Z'});
  assert.equal((await request('/api/availability?date=2027-01-05&resourceId=washer-1')).data.resources[0].slots[0].available,true);
  assert.equal((await request('/api/bookings',{method:'POST',body:booking('2027-01-05T21:30+01:00','2027-01-05T22:00+01:00')})).status,201);
  assert.equal((await request('/api/bookings',{method:'POST',body:booking('2027-01-05T07:00+01:00','2027-01-05T10:00+01:00')})).status,201);
});
test('linked usage excludes booking end and does not allow wrong resource',async t=>{
  let current=NOW;const {request}=await fixture(t,{now:()=>current});
  const b=(await request('/api/bookings',{method:'POST',body:booking()})).data.booking;
  current=b.start;
  assert.equal((await request('/api/usage/checkin',{method:'POST',body:{resourceId:'washer-2',bookingId:b.id}})).status,409);
  current=b.end;
  assert.equal((await request('/api/usage/checkin',{method:'POST',body:{resourceId:'washer-1',bookingId:b.id}})).status,409);
});
test('static hosting handles SPA routes and missing assets without masking API errors',async t=>{
  const dir=await mkdtemp(join(tmpdir(),'dormitory-static-'));
  await writeFile(join(dir,'index.html'),'<html>demo build</html>');await writeFile(join(dir,'app.js'),'export const demo=true;');
  const {base}=await fixture(t,{staticDir:dir});
  t.after(async()=>{assert.ok(dir.startsWith(join(tmpdir(),'dormitory-static-')));await rm(dir,{recursive:true,force:true});});
  assert.equal(await (await fetch(base+'/')).text(),'<html>demo build</html>');
  assert.equal(await (await fetch(base+'/personal/bookings')).text(),'<html>demo build</html>');
  assert.equal((await fetch(base+'/app.js')).headers.get('content-type'),'text/javascript; charset=utf-8');
  assert.equal((await fetch(base+'/missing.js')).status,404);
  assert.equal((await fetch(base+'/api/missing')).status,404);
});
test('CORS permits only configured dev origin',async t=>{
  const {request}=await fixture(t);
  const allowed=await request('/api/resources',{headers:{Origin:'http://localhost:5173'}});assert.equal(allowed.headers.get('access-control-allow-origin'),'http://localhost:5173');
  assert.equal((await request('/api/resources',{headers:{Origin:'https://untrusted.example'}})).headers.get('access-control-allow-origin'),null);
  assert.equal((await request('/api/resources',{method:'OPTIONS'})).status,204);
});
