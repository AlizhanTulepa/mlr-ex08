import React, { useEffect, useRef, useState } from 'react';
import { api, DEMO_USER, notifyDataChanged } from '../api';
import { pragueInstants, pragueOffset, formatPragueDateTime as dateTime } from './receptionTime.mjs';
import './reception.css';

const name = resource => resource?.name.replace(/^Demo /, '').replace(/^./, c => c.toUpperCase()) || 'Resource';
const current = (interval, now) => Date.parse(interval.start) <= now && now < Date.parse(interval.end);

function DateTimeField({ label, value, onChange, occurrence, onOccurrenceChange }) {
  const options = pragueInstants(value);
  return <div>
    <label><span>{label} (Prague)</span><input type="datetime-local" required min="1000-01-01T00:00" max="9999-12-31T23:59" step="60" value={value} onChange={e => { onChange(e.target.value); onOccurrenceChange(0); }}/></label>
    {options.length > 1 && <label className="reception-offset"><span>{label} UTC offset — clock changes on this date</span><select value={occurrence} onChange={e => onOccurrenceChange(Number(e.target.value))}>{options.map((instant, i) => <option key={instant} value={i}>{pragueOffset(instant)} ({i === 0 ? 'first' : 'second'} occurrence)</option>)}</select></label>}
  </div>;
}

export default function Reception() {
  const [data, setData] = useState(null);
  const [resourceId, setResourceId] = useState('');
  const [revision, setRevision] = useState(0);
  const [fetching, setFetching] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [pending, setPending] = useState('');
  const mutationInFlight = useRef(false);
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [startOccurrence, setStartOccurrence] = useState(0);
  const [endOccurrence, setEndOccurrence] = useState(0);
  const [reason, setReason] = useState('');
  const [now, setNow] = useState(Date.now);
  const refresh = () => setRevision(value => value + 1);

  useEffect(() => {
    const onChange = () => setRevision(value => value + 1);
    window.addEventListener('dormitory:data-changed', onChange);
    const timer = setInterval(onChange, 30000);
    return () => { window.removeEventListener('dormitory:data-changed', onChange); clearInterval(timer); };
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    setFetching(true);
    setLoadError('');
    Promise.all([api.resources(controller.signal), api.maintenance(controller.signal),
      api.usage(controller.signal), api.receptionBookings(controller.signal)])
      .then(([resources, maintenance, usage, bookings]) => {
        if (controller.signal.aborted) return;
        setData({ ...resources, ...maintenance, ...usage, ...bookings });
        setResourceId(id => resources.resources.some(r => r.id === id) ? id : resources.resources[0]?.id || '');
        setNow(Date.now());
      }).catch(e => {
        if (!controller.signal.aborted && e.name !== 'AbortError') setLoadError(`Could not refresh reception data. ${e.message}`);
      }).finally(() => { if (!controller.signal.aborted) setFetching(false); });
    return () => controller.abort();
  }, [revision]);

  const resources = data?.resources || [];
  const resource = resources.find(r => r.id === resourceId);
  const maintenance = (data?.maintenance || []).filter(m => m.resourceId === resourceId);
  const usage = (data?.usage || []).filter(u => u.resourceId === resourceId);
  const activeUsage = usage.find(u => !u.checkedOutAt);
  const activeMaintenance = maintenance.find(m => current(m, now));
  const bookings = (data?.bookings || []).filter(b => b.resourceId === resourceId && Date.parse(b.end) > now);
  const initialLoading = !data && fetching;
  const refreshing = !!data && fetching;
  // A refresh is only a snapshot update. The server validates every submitted change,
  // including when the latest background read failed; typing must remain uninterrupted.
  const ready = !!resource && !pending;

  async function mutate(key, operation, message, onSuccess) {
    if (!ready || mutationInFlight.current) return;
    mutationInFlight.current = true;
    setPending(key); setError(''); setSuccess('');
    try {
      await operation();
      onSuccess?.();
      setSuccess(message);
      notifyDataChanged();
    } catch (e) {
      setError(`${e.message}${e.status === 409 ? ' Data is being refreshed. Review the latest periods and reservations before trying again.' : ''}`);
      if (e.status === 409 || e.status === 404) refresh();
    } finally { mutationInFlight.current = false; setPending(''); }
  }

  function createMaintenance(event) {
    event.preventDefault();
    if (!ready || mutationInFlight.current) return;
    setSuccess(''); setError('');
    const startInstant = pragueInstants(start)[startOccurrence];
    const endInstant = pragueInstants(end)[endOccurrence];
    if (!startInstant || !endInstant) {
      setError('Enter valid start and end times in Prague. A time skipped by the spring clock change does not exist.');
      return;
    }
    if (Date.parse(endInstant) <= Date.parse(startInstant)) { setError('End must be after start.'); return; }
    if (!reason.trim()) { setError('Enter a maintenance reason.'); return; }
    mutate('create', () => api.createMaintenance({ resourceId, start: startInstant, end: endInstant, reason: reason.trim() }),
      `Maintenance saved for ${name(resource)}. The period is now blocked for reservations.`, () => { setReason(''); });
  }

  return <main className="reception">
    <div className="reception-heading"><div><p className="reception-eyebrow">Reception / Resources</p><h1>Keep resources ready.</h1><p>Manage maintenance and record actual use separately from reservations.</p></div><button type="button" className="reception-button" onClick={refresh} disabled={fetching || !!pending}>{initialLoading ? 'Loading…' : refreshing ? 'Refreshing…' : 'Refresh data'}</button></div>
    <p className="reception-timezone">All dates and times: Europe/Prague · Demo identity: {DEMO_USER}</p>
    <div className="reception-feedback">
      {initialLoading && <p role="status">Loading resources, maintenance and usage…</p>}
      {refreshing && <p role="status">Refreshing reception data… You can continue editing.</p>}
      {loadError && <div className="reception-error" role="alert"><p>{loadError}</p><p>{data ? 'Previously loaded information is shown below. You can continue editing; the server checks every submitted change against current data.' : 'Use Retry to load reception.'}</p><button className="reception-button" onClick={refresh} disabled={fetching}>Retry</button></div>}
      {error && <p className="reception-error" role="alert">{error}</p>}
      {success && <p className="reception-success" role="status">{success}</p>}
    </div>
    {data && <div className="reception-workspace">
      <aside className="reception-resources" aria-labelledby="reception-resources-title"><h2 id="reception-resources-title">Resources</h2>
        {resources.length === 0 && <p>No resources are configured.</p>}
        <div className="reception-resource-list">{resources.map(r => {
          const occupied = data.usage.some(u => u.resourceId === r.id && !u.checkedOutAt);
          const blocked = data.maintenance.some(m => m.resourceId === r.id && current(m, now));
          return <button type="button" className="reception-resource" key={r.id} aria-pressed={resourceId === r.id} disabled={!!pending} onClick={() => { setResourceId(r.id); setSuccess(''); setError(''); }}><strong>{name(r)}</strong><span>{r.type === 'washer' ? 'Laundry · one machine' : 'Study room · whole room'}</span><span>{loadError ? 'Status unavailable' : refreshing ? 'Updating status…' : `${occupied ? 'In use' : 'No active use'} · ${blocked ? 'Under maintenance' : 'No maintenance now'}`}</span></button>;
        })}</div>
        <p className="reception-help">A reservation does not mean someone is physically present. No active use does not guarantee a free reservation slot.</p>
        <p className="reception-help">Planned: resource editing and configurable opening hours. Demo hours: {data.policy.opensAt}–{data.policy.closesAt}.</p>
      </aside>
      {resource && <div className="reception-detail">
        <section className="reception-panel" aria-labelledby="maintenance-title"><h2 id="maintenance-title">Maintenance · {name(resource)}</h2><p className="reception-help">Blocks reservations for this resource. Existing confirmed bookings and maintenance cannot overlap. Past and multiday periods are allowed.</p>
          <form onSubmit={createMaintenance}>
            <fieldset disabled={!ready}><legend>Create a maintenance period</legend>
              <label><span>Resource</span><select value={resourceId} onChange={e => { setResourceId(e.target.value); setError(''); setSuccess(''); }}>{resources.map(r => <option key={r.id} value={r.id}>{name(r)}</option>)}</select></label>
              <div className="reception-date-fields"><DateTimeField label="Start" value={start} onChange={setStart} occurrence={startOccurrence} onOccurrenceChange={setStartOccurrence}/><DateTimeField label="End" value={end} onChange={setEnd} occurrence={endOccurrence} onOccurrenceChange={setEndOccurrence}/></div>
              <label><span>Reason</span><textarea required maxLength={1000} rows={3} value={reason} onChange={e => setReason(e.target.value)} placeholder="For example: scheduled inspection"/></label>
              <button className="reception-primary" type="submit">{pending === 'create' ? 'Saving…' : 'Block maintenance time'}</button>
            </fieldset>
          </form>
          <h3>Saved maintenance periods</h3>
          {!maintenance.length ? <p className="reception-empty">No maintenance periods for this resource.</p> : <ul className="reception-records">{maintenance.map(m => <li key={m.id}><div><span className="reception-badge">{current(m, now) ? 'Under maintenance now' : Date.parse(m.end) <= now ? 'Past period' : 'Upcoming maintenance'}</span><p><time dateTime={m.start}>{dateTime(m.start)}</time> – <time dateTime={m.end}>{dateTime(m.end)}</time></p><p className="reception-reason">{m.reason}</p></div><button className="reception-button" disabled={!ready} aria-label={`Remove maintenance: ${m.reason}, ${dateTime(m.start)}`} onClick={() => mutate(`remove-${m.id}`, () => api.deleteMaintenance(m.id), 'Maintenance removed. The period can be reserved if no other booking or maintenance overlaps.')} type="button">{pending === `remove-${m.id}` ? 'Removing…' : 'Remove block'}</button></li>)}</ul>}
        </section>
        <section className="reception-panel" aria-labelledby="usage-title"><h2 id="usage-title">Actual use</h2><p className="reception-help">Check-in and check-out record the server time. Usage does not reserve future slots or end automatically.</p>
          {activeUsage ? <div className="reception-current-use"><span className="reception-badge">In use now</span><p>{activeUsage.userId} · checked in <time dateTime={activeUsage.checkedInAt}>{dateTime(activeUsage.checkedInAt)}</time></p><p className="reception-help">{activeUsage.bookingId ? `Linked reservation: ${activeUsage.bookingId}` : 'Walk-in · no linked reservation'}</p><button type="button" className="reception-primary" disabled={!ready} onClick={() => mutate('checkout', () => api.checkOut(activeUsage.id), `Check-out recorded for ${name(resource)}.`)}>{pending === 'checkout' ? 'Recording…' : 'Check out'}</button></div> : <div className="reception-current-use"><p><strong>No active usage recorded.</strong></p>{activeMaintenance && <p>Check-in is unavailable during current maintenance.</p>}<button type="button" className="reception-primary" disabled={!ready || !!activeMaintenance} onClick={() => mutate('checkin', () => api.checkIn({ resourceId }), `Walk-in check-in recorded for ${name(resource)}.`)}>{pending === 'checkin' ? 'Recording…' : 'Check in walk-in'}</button><p className="reception-help">Walk-in records {DEMO_USER} without linking a reservation.</p></div>}
          <details className="reception-history"><summary>Completed usage ({usage.filter(u => u.checkedOutAt).length})</summary><ul className="reception-records">{usage.filter(u => u.checkedOutAt).sort((a, b) => b.checkedInAt.localeCompare(a.checkedInAt)).map(u => <li key={u.id}><div><strong>{u.userId}</strong><p>In: <time dateTime={u.checkedInAt}>{dateTime(u.checkedInAt)}</time></p><p>Out: <time dateTime={u.checkedOutAt}>{dateTime(u.checkedOutAt)}</time></p><p className="reception-help">{u.bookingId ? `Linked reservation: ${u.bookingId}` : 'Walk-in'}</p></div></li>)}</ul>{!usage.some(u => u.checkedOutAt) && <p className="reception-empty">No completed usage yet.</p>}</details>
        </section>
        <section className="reception-panel" aria-labelledby="reception-bookings-title"><h2 id="reception-bookings-title">Current & future reservations</h2><p className="reception-help">Confirmed reservations for all demo users. These show planned time, not physical occupancy. Only an underway reservation owned by {DEMO_USER} can be linked at check-in.</p>
          {!bookings.length ? <p className="reception-empty">No current or future reservations for this resource.</p> : <ul className="reception-records">{bookings.map(b => <li key={b.id}><div><span className="reception-badge">{current(b, now) ? 'Reservation underway' : 'Future reservation'}</span><p><strong>{b.userId}</strong></p><p><time dateTime={b.start}>{dateTime(b.start)}</time> – <time dateTime={b.end}>{dateTime(b.end)}</time></p><p className="reception-help">Reservation {b.id}</p></div>{current(b, now) && b.userId === DEMO_USER && <button type="button" className="reception-button" disabled={!ready || !!activeUsage || !!activeMaintenance} onClick={() => mutate(`checkin-${b.id}`, () => api.checkIn({ resourceId, bookingId: b.id }), `Reservation check-in recorded for ${name(resource)}.`)}>{pending === `checkin-${b.id}` ? 'Recording…' : 'Check in reservation'}</button>}</li>)}</ul>}
        </section>
      </div>}
    </div>}
    <footer><span>Demonstration data · no real reception role authentication</span><span>Updates after changes and every 30 seconds.</span></footer>
  </main>;
}
