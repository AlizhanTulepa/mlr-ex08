import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { WashingMachine, BookOpen, ArrowRight, CalendarDays, Check, RefreshCw, Clock3, Building2 } from 'lucide-react';
import { api, DEMO_USER, notifyDataChanged } from './api';
import Reception from './modules/Reception';
import MyBookings from './modules/MyBookings';
import './styles.css';

const TZ = 'Europe/Prague';
const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
const time = value => new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', minute: '2-digit' }).format(new Date(value));
const displayName = resource => resource?.name.replace(/^Demo /, '').replace(/^./, c => c.toUpperCase()) || '';
const dateLabel = value => !/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(Date.parse(`${value}T12:00:00Z`)) ? 'Choose a valid date' : new Intl.DateTimeFormat('en-GB', { timeZone: TZ, weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(`${value}T12:00:00Z`));

function AvailabilityPage() {
  const [resources, setResources] = useState([]);
  const [resourceError, setResourceError] = useState('');
  const [resourceId, setResourceId] = useState('');
  const [category, setCategory] = useState('all');
  const [date, setDate] = useState(today);
  const [duration, setDuration] = useState(60);
  const [availability, setAvailability] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [confirmation, setConfirmation] = useState(null);
  const [revision, setRevision] = useState(0);
  const refresh = () => setRevision(v => v + 1);

  useEffect(() => {
    const controller = new AbortController();
    setResourceError('');
    api.resources(controller.signal).then(data => {
      setResources(data.resources);
      setResourceId(id => id || data.resources[0]?.id || '');
    }).catch(e => { if (e.name !== 'AbortError') setResourceError(e.message); });
    return () => controller.abort();
  }, [revision]);

  useEffect(() => {
    window.addEventListener('dormitory:data-changed', refresh);
    const interval = setInterval(refresh, 30000);
    return () => { window.removeEventListener('dormitory:data-changed', refresh); clearInterval(interval); };
  }, []);

  useEffect(() => {
    if (!date) { setAvailability([]); setLoading(false); return; }
    const controller = new AbortController();
    setLoading(true);
    setError('');
    api.availability(date, duration, controller.signal).then(data => {
      setAvailability(data.resources);
      setSelected(old => old && data.resources.find(r => r.resourceId === resourceId)?.slots.some(s => s.start === old.start && s.available) ? old : null);
    }).catch(e => { if (e.name !== 'AbortError') { setError(e.message); setAvailability([]); } })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [date, duration, revision, resourceId]);

  const resource = resources.find(r => r.id === resourceId);
  const slots = availability.find(r => r.resourceId === resourceId)?.slots || [];
  const visibleResources = resources.filter(r => category === 'all' || r.type === category);
  const reasons = { booking: 'Reserved', maintenance: 'Maintenance', past: 'Past' };

  function chooseResource(r) { setResourceId(r.id); setSelected(null); setConfirmation(null); }
  function chooseCategory(value) {
    setCategory(value);
    if (value !== 'all' && resource?.type !== value) {
      const next = resources.find(r => r.type === value);
      if (next) chooseResource(next);
    }
  }
  async function book(event) {
    event.preventDefault();
    if (!selected || submitting) return;
    setSubmitting(true); setError(''); setConfirmation(null);
    try {
      const result = await api.createBooking({ resourceId, start: selected.start, end: selected.end });
      setConfirmation({ ...result.booking, resourceName: resource.name });
      setSelected(null);
      notifyDataChanged();
    } catch (e) {
      setError(e.status === 409 ? 'This time is no longer available. Choose another slot below.' : e.message);
      refresh();
    } finally { setSubmitting(false); }
  }

  return <>
    <main>
      <div className="page-heading"><div><p className="breadcrumb">Resident / Availability</p><h1>A little planning. A free slot.</h1><p>Find a washing machine or a quiet room, without a trip to reception.</p></div><div className="timezone"><Clock3 size={16}/><span>All times in Prague</span></div></div>
      <div className="workspace">
        <aside className="resources" aria-label="Choose a resource"><h2>What do you need?</h2>
          <div className="filter" aria-label="Resource type">{[['all', 'All'], ['washer', 'Laundry'], ['study_room', 'Study rooms']].map(([value, label]) => <button key={value} disabled={submitting} aria-pressed={category === value} onClick={() => chooseCategory(value)}>{label}</button>)}</div>
          {visibleResources.length === 0 ? <p className="muted">{resources.length ? 'No resources in this category.' : resourceError ? 'Resources could not be loaded. Use Try again.' : 'Loading resources…'}</p> : <div className="resource-list">{visibleResources.map(r => {
            const free = availability.find(a => a.resourceId === r.id)?.slots.filter(s => s.available).length;
            return <button key={r.id} disabled={submitting} className={`resource ${resourceId === r.id ? 'selected' : ''}`} aria-pressed={resourceId === r.id} onClick={() => chooseResource(r)}>
              <span className="resource-icon">{r.type === 'washer' ? <WashingMachine size={22}/> : <BookOpen size={22}/>}</span><span className="resource-copy"><strong>{displayName(r)}</strong><span>{r.type === 'washer' ? 'Laundry · one machine' : 'Study room · whole room'}</span><small>{loading ? 'Checking times…' : `${free || 0} start times available`}</small></span>{resourceId === r.id && <Check size={17} className="resource-check"/>}
            </button>;
          })}</div>}
          <div className="aside-note"><strong>Before you reserve</strong><p>A reservation holds your time slot. It does not confirm that a previous user has returned the key.</p></div>
        </aside>
        <section className="booking-section" aria-labelledby="schedule-heading">
          <div className="section-heading"><div><p className="muted">Availability & booking</p><h2 id="schedule-heading">{displayName(resource) || 'Choose a resource'}</h2></div><button className="icon-button" onClick={refresh} aria-label="Refresh availability" disabled={loading}><RefreshCw size={18}/></button></div>
          <div className="controls"><label><span><CalendarDays size={15}/> Date</span><input type="date" disabled={submitting} min={today()} max="9999-12-31" value={date} onChange={e => { setDate(e.target.value); setSelected(null); setConfirmation(null); }}/></label><label><span><Clock3 size={15}/> How long?</span><select disabled={submitting} value={duration} onChange={e => { setDuration(Number(e.target.value)); setSelected(null); setConfirmation(null); }}>{[30,60,90,120,150,180].map(n => <option key={n} value={n}>{n < 60 ? '30 minutes' : `${n / 60} ${n === 60 ? 'hour' : 'hours'}`}</option>)}</select></label></div>
          {confirmation && <div className="success" role="status"><Check size={21}/><div><strong>You’re booked.</strong><p>{displayName({name: confirmation.resourceName})} · {time(confirmation.start)}–{time(confirmation.end)} · {dateLabel(new Intl.DateTimeFormat('en-CA', {timeZone: TZ}).format(new Date(confirmation.start)))}</p><small>Reservation {confirmation.id} · Saved on the server.</small></div></div>}
          {(error || resourceError) && <div className="error" role="alert">{error || resourceError} <button onClick={refresh}>Try again</button></div>}
          <div className="schedule-title"><h3>{date ? dateLabel(date) : 'Choose a date'}</h3><span>07:00–22:00</span></div>
          <p className="slot-help">Choose a start time. Each slot reserves the full {duration} minutes.</p>
          {loading ? <div className="skeleton" role="status" aria-label="Loading availability">{Array.from({length:12}, (_,i) => <span key={i}/>)}</div> : <div className="slots" aria-label="Available start times">{slots.map(slot => <button key={slot.start} disabled={!slot.available || submitting} aria-pressed={selected?.start === slot.start} className={`slot ${selected?.start === slot.start ? 'chosen' : ''}`} onClick={() => { setSelected(slot); setConfirmation(null); }}><strong>{time(slot.start)}</strong><span>{slot.available ? `until ${time(slot.end)}` : reasons[slot.reason] || 'Unavailable'}</span></button>)}</div>}
          {!loading && !slots.some(s => s.available) && <p className="empty">No available times for this duration. Try a shorter booking or another date.</p>}
          <form className="booking-bar" onSubmit={book}><div><span className="muted">Your reservation</span><strong>{selected ? `${time(selected.start)}–${time(selected.end)} · ${duration} min` : 'Select an available time above'}</strong><span className="muted">{selected ? `${displayName(resource)} · ${DEMO_USER}` : 'No payment required in this prototype'}</span></div><button className="primary" disabled={!selected || submitting || loading} type="submit">{submitting ? 'Reserving…' : 'Reserve this time'}<ArrowRight size={18}/></button></form>
        </section>
      </div>
      <footer><span>Demonstration data · not connected to dormitory reception</span><span>Opening hours and booking rules are proposed, not verified.</span></footer>
    </main>
  </>;
}
function App() {
  const readPage = () => window.location.hash === '#reception' ? 'reception' : window.location.hash === '#my-bookings' ? 'my-bookings' : 'availability';
  const [page, setPage] = useState(readPage);
  useEffect(() => {
    const onHashChange = () => setPage(readPage());
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);
  return <>
    <header className="header"><a className="brand" href="#availability" aria-label="Dormitory home"><Building2 size={24}/><span>Dormitory<span className="brand-sub">Resource booking</span></span></a><div className="identity"><span className="demo">Course prototype</span><span className="avatar" aria-hidden="true">AB</span><span>{DEMO_USER}</span></div></header>
    <nav className="app-navigation" aria-label="Main navigation"><a href="#availability" aria-current={page === 'availability' ? 'page' : undefined}>Availability & booking</a><a href="#my-bookings" aria-current={page === 'my-bookings' ? 'page' : undefined}>My bookings</a><a href="#reception" aria-current={page === 'reception' ? 'page' : undefined}>Reception</a></nav>
    <div hidden={page !== 'availability'}><AvailabilityPage/></div>
    <div hidden={page !== 'my-bookings'}><MyBookings/></div>
    <div hidden={page !== 'reception'}><Reception/></div>
  </>;
}
createRoot(document.getElementById('root')).render(<React.StrictMode><App/></React.StrictMode>);
