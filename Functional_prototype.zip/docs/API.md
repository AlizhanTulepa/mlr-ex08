# Dormitory resource booking — demo API

## Scope and running

Module A implements resource listing, Prague-date availability, time selection data and transactional booking creation. The same backend supplies a shared foundation for module B (own bookings, rescheduling, cancellation) and module C (reception maintenance and actual occupancy). The Reception React screen now consumes module C endpoints through `src/api.js`; no backend routes or models were added for this integration. Module B UI remains planned.

Runtime: **Node.js >=22.13**, with built-in `node:sqlite` `DatabaseSync`, `node:http`, plain JavaScript ES modules (`.mjs`). SQLite may emit an experimental warning on Node 22. No framework, native addon, npm dependency or external database is required. Implementation verified using Node v25.8.1. Node versions without `node:sqlite` are unsupported; do not silently fall back to volatile storage.

```sh
node server/index.mjs
node --watch server/index.mjs
node --test server/test/*.test.mjs
TZ=America/Los_Angeles node --test server/test/*.test.mjs
```

Default API: `http://127.0.0.1:3001/api`. Environment variables: `PORT` (3001), `HOST` (127.0.0.1), `DATABASE_PATH` (absolute recommended; default `server/data/bookings.sqlite`), `CORS_ORIGIN` (`http://localhost:5173`). The server creates the database directory and tables, then seeds five **explicitly fictional demo resources**: `washer-1`, `washer-2`, `washer-3`, `study-room-1`, `study-room-2`. Restarting preserves existing bookings and usage. SQLite data/WAL files are ignored by `server/.gitignore`.

Vite development: proxy `/api` to `http://127.0.0.1:3001` and call relative API URLs. This avoids cross-origin concerns. Direct calls from exactly `CORS_ORIGIN` also receive CORS headers, including permission for `X-Demo-User`. Other origins receive no CORS permission. **CORS is not access control.** The backend also serves the built root `dist/` directory on the same port, with SPA navigation fallback, when that frontend build exists. It does not build the frontend itself.

## Demo identity and security limitations

`X-Demo-User: xbatyra00` selects a demo identity. Omitting it uses `xbatyra00`. Values must be 1–64 ASCII letters, digits, underscores, dots or hyphens, starting with a letter/digit.

**This is not authentication or authorization suitable for deployment.** Anyone can impersonate another demo identity. Booking mutation checks the supplied identity against the stored owner. Reception-style endpoints (all bookings, maintenance, occupancy checkout) are deliberately available without secure role authentication. Unlinked reception check-in records the supplied user identity. Booking-linked check-in requires that identity to own the booking. Do not expose the demo publicly or store sensitive personal data. Before production, add real identity/session handling, reception role enforcement, CSRF protections where applicable, rate limiting and deployment controls.

## Proposed demo booking policy

These are demonstration rules, **not claims about a real dormitory**:

- Business timezone: **Europe/Prague**, independent of server/browser timezone. IANA timezone rules come from the Node runtime's ICU timezone data.
- Daily opening hours: **07:00–22:00**, including weekends; no holiday calendar.
- Starts and ends align to Prague 30-minute boundaries; seconds and fractional seconds must be zero.
- Duration is **30–180 minutes**, in 30-minute increments, within one Prague calendar day.
- A booking cannot start before the injected/current time. An exactly-current start is allowed.
- A study-room booking reserves the **whole room**, not individual seats. All resource `capacity` values are one reservable unit.
- All request timestamps require an explicit offset: `2027-01-05T09:00:00+01:00` or `2027-01-05T08:00:00Z`. Offsetless strings, invalid dates/clocks/offsets and leap seconds are rejected. Offset need not be Prague's current offset: the represented instant is validated against Prague business hours. A client with a nonexistent local DST wall time should use the generated availability timestamps instead of constructing it manually.
- Conflicts use half-open intervals **[start, end)**: an event ending at 10:00 permits another starting at 10:00. Confirmed bookings and maintenance both block the same resource; cancelled bookings do not.
- Maintenance is administrative downtime: any valid ordered timestamp interval is allowed, including past/multiday/outside-opening-hours intervals. It cannot overlap a confirmed booking or another maintenance block. Moving/adding maintenance does not silently cancel bookings; reception must resolve those bookings first.
- Actual occupancy is a separate observation, not a future reservation. A booking does **not** imply someone is physically present. Active occupancy does **not** automatically block future reservation slots or auto-end at a booked end; reception is responsible for checkout/overruns.

## Common response conventions

Content type: `application/json; charset=utf-8`. POST/PATCH bodies must have `Content-Type: application/json`, be JSON objects with only documented fields, and fit **16 KiB**. Unknown fields and missing required fields are errors; clients cannot supply booking status, identity or identifiers. IDs are opaque UUIDs except seeded resource IDs. Timestamps in stored-entity responses use UTC `Z`; availability slots deliberately use Prague offsets.

Errors always use:

```json
{"error":{"code":"TIME_CONFLICT","message":"Time overlaps an existing booking"}}
```

Statuses: `200` read/update/cancel/checkout, `201` created, `204` maintenance deleted or OPTIONS, `400` invalid input, `403` not booking owner, `404` missing resource/entity/route, `409` business conflict, `413` body too large, `415` unsupported request media type, `503` database temporarily busy, `500` unexpected internal error. Unsupported route/method combinations return `404` (not method negotiation). Errors do not expose internal stack traces.

Key error codes include `INVALID_DATE`, `INVALID_TIMESTAMP`, `INVALID_DURATION`, `INVALID_ALIGNMENT`, `OUTSIDE_OPEN_HOURS`, `PAST_BOOKING`, `TIME_CONFLICT`, `NOT_OWNER`, `BOOKING_CANCELLED`, `BOOKING_STARTED`, `RESOURCE_NOT_FOUND`, `BOOKING_NOT_FOUND`, `MAINTENANCE_NOT_FOUND`, `USAGE_NOT_FOUND`, `ALREADY_OCCUPIED`, `UNDER_MAINTENANCE`, `INVALID_CHECK_IN`, `INVALID_BODY`, `MISSING_FIELD`, `UNKNOWN_FIELD`, `INVALID_FIELD`, `INVALID_JSON`, `BODY_TOO_LARGE` and `INVALID_DEMO_USER`.

## Resources and availability — module A

### GET /api/health

```json
{"status":"ok","demo":true}
```

### GET /api/resources

```json
{
  "resources": [
    {"id":"washer-1","name":"Demo washer 1","type":"washer","description":"Fictional demonstration resource","capacity":1},
    {"id":"study-room-1","name":"Demo study room 1","type":"study_room","description":"Fictional demonstration resource; booking reserves the whole room, not a seat","capacity":1}
  ],
  "policy":{"timeZone":"Europe/Prague","opensAt":"07:00","closesAt":"22:00","slotMinutes":30,"minDurationMinutes":30,"maxDurationMinutes":180,"demo":true}
}
```

The example omits three resources for brevity; the response contains all five. Do not depend on array ordering.

### GET /api/availability?date=2027-01-05&durationMinutes=60&resourceId=washer-1

`date` is required, strictly `YYYY-MM-DD` in Prague (real calendar date, year 1000–9999). Optional `durationMinutes` defaults to 30; allowed 30, 60, 90, 120, 150, 180. Optional `resourceId` limits results; otherwise all resources are returned. Each possible half-hour start whose full requested duration fits opening hours is returned. The start/end pair is suitable for POST directly.

```json
{
  "date":"2027-01-05",
  "timeZone":"Europe/Prague",
  "durationMinutes":60,
  "resources":[{"resourceId":"washer-1","slots":[
    {"start":"2027-01-05T07:00:00+01:00","end":"2027-01-05T08:00:00+01:00","available":true,"reason":null},
    {"start":"2027-01-05T07:30:00+01:00","end":"2027-01-05T08:30:00+01:00","available":false,"reason":"booking"}
  ]}]
}
```

Slots are omitted in the example for brevity. `reason` is `null`, `past`, `booking`, or `maintenance` (past takes precedence). This is a snapshot, **not a lock**; clients must handle a subsequent create returning 409 and refresh availability.

### POST /api/bookings

```sh
curl -i http://127.0.0.1:3001/api/bookings \
  -H 'Content-Type: application/json' -H 'X-Demo-User: xbatyra00' \
  -d '{"resourceId":"washer-1","start":"2027-01-05T09:00:00+01:00","end":"2027-01-05T10:00:00+01:00"}'
```

Dates in curl examples must be changed to future dates when necessary.

Body: `{resourceId: string, start: timestamp, end: timestamp}`. Returns 201:

```json
{"booking":{"id":"opaque-uuid","resourceId":"washer-1","userId":"xbatyra00","start":"2027-01-05T08:00:00.000Z","end":"2027-01-05T09:00:00.000Z","status":"confirmed","createdAt":"2027-01-01T10:00:00.000Z","updatedAt":"2027-01-01T10:00:00.000Z"}}
```

## Personal bookings — shared module B foundation

### GET /api/bookings

Returns `{bookings: Booking[]}` sorted by start and ID. Defaults to own bookings (including cancelled). Optional filters: `resourceId`, `status=confirmed|cancelled`, `scope=mine|all`. `scope=all` is the demo reception overview and is not secured. No pagination in this demo.

### PATCH /api/bookings/:id

Required body: `{start: timestamp, end: timestamp}`. Reschedules the existing resource only, returns `{booking: Booking}`. Only the supplied demo owner may modify. Checks the same creation rules, excluding this booking from the overlap query. Rejection leaves the original booking untouched. Cancelled or already-started bookings cannot be rescheduled (409). Resource changes require cancellation and a new booking.

```sh
curl -X PATCH http://127.0.0.1:3001/api/bookings/BOOKING_ID \
  -H 'Content-Type: application/json' -H 'X-Demo-User: xbatyra00' \
  -d '{"start":"2027-01-05T10:00:00+01:00","end":"2027-01-05T11:00:00+01:00"}'
```

### DELETE /api/bookings/:id

Soft cancellation, returning `{booking: Booking}` with `status: "cancelled"`. Owner-only; repeat cancellation is safe/idempotent. A confirmed booking whose start is already in the past cannot be cancelled (409). Cancelled records remain in history and free their interval immediately. No body required.

## Maintenance — shared module C foundation

Reception UI supports list/create/delete below, filtering the loaded periods by selected resource.
The existing PATCH endpoint remains available to clients; editing a maintenance period is not exposed
in this screen. Resource CRUD and opening-hour configuration remain planned and have no endpoints.

- `GET /api/maintenance[?resourceId=washer-1]` → `{maintenance: Maintenance[]}`.
- `POST /api/maintenance` body `{resourceId,start,end,reason}` → 201 `{maintenance: Maintenance}`.
- `PATCH /api/maintenance/:id` body any subset of `{resourceId,start,end,reason}` → `{maintenance: Maintenance}`; omitted values retained.
- `DELETE /api/maintenance/:id` → 204; missing ID → 404.

`Maintenance` is `{id,resourceId,start,end,reason,createdAt,updatedAt}`. `reason` is a nonempty string of at most 1000 characters. Both create and update check the common overlap service inside a transaction, ignoring only the block being updated.

```sh
curl http://127.0.0.1:3001/api/maintenance \
  -H 'Content-Type: application/json' \
  -d '{"resourceId":"washer-2","start":"2027-01-05T07:00:00+01:00","end":"2027-01-05T12:00:00+01:00","reason":"Fictional demo inspection"}'
```

## Actual occupancy — shared module C foundation

Reception shows current usage and completed sessions separately from confirmed current/future
reservations (`GET /api/bookings?scope=all&status=confirmed`). It supports walk-in check-in,
check-in linked to an underway booking owned by the shared demo identity, and active-session checkout.
Successful writes dispatch `notifyDataChanged()` to refresh both mounted screens without reload.

- `GET /api/usage[?active=true&resourceId=washer-1]` → `{usage: Usage[]}`. Optional `active=true|false` filters active/completed sessions. Omitted returns both.
- `POST /api/usage/checkin` body `{resourceId,bookingId?}` → 201 `{usage: Usage}`.
- `POST /api/usage/:id/checkout` → `{usage: Usage}`. No body required; repeated checkout returns the same timestamp.

`Usage` is `{id,resourceId,bookingId: string|null,userId,checkedInAt,checkedOutAt: timestamp|null}`. At most one active usage session per resource, enforced by a SQLite partial unique index. Optional `bookingId` must refer to the current resource, be confirmed and currently underway (`start <= now < end`), and belong to the supplied demo user. Without `bookingId`, reception can record walk-in use independently from reservations. Current maintenance prevents check-in. Timestamps come from the server clock; clients cannot backdate usage. There is no automatic checkout/background job. Checkout is a reception demo operation without owner restriction. Current usage does not alter booked or maintenance intervals.

```sh
curl http://127.0.0.1:3001/api/usage/checkin \
  -H 'Content-Type: application/json' -d '{"resourceId":"study-room-1"}'
curl 'http://127.0.0.1:3001/api/usage?active=true'
curl -X POST http://127.0.0.1:3001/api/usage/USAGE_ID/checkout
```

## Implementation and test integration

- `server/app.mjs` exports `createApp({dbPath = ':memory:', now = () => new Date(), staticDir?, corsOrigin?})`, returning `{server,service,close}`. Tests listen on `server.listen(0, '127.0.0.1')` and await `close()`. Importing the factory never starts listening or writes the default disk database.
- `server/service.mjs` exports `createService({dbPath,now})`. It owns schema initialization, seed data, validation/ownership and transactional operations. `service.close()` closes SQLite. The HTTP layer returns only validated JSON entities; SQL uses bound parameters.
- `server/time.mjs` handles strict date/timestamp parsing and Prague wall-time conversion. Availability is generated between 07:00 and 22:00, avoiding the ambiguous/nonexistent 02:00 DST transition itself; emitted offsets still change correctly on transition dates.
- `server/index.mjs` is the persistent executable entrypoint. It binds loopback by default and handles SIGINT/SIGTERM shutdown.
- All conflicting writes use **BEGIN IMMEDIATE**, overlap check, write, COMMIT, rolling back on errors. SQLite serializes writers even across independent connections/processes. WAL and 5-second busy timeout are configured. The shared predicate is `existing.start < requested.end AND existing.end > requested.start`, restricted to the same resource. Confirmation and maintenance writers use the same transaction/overlap service.
- Tests cover overlap/adjacency, reschedule self-exclusion and rollback, cancellation/ownership, maintenance CRUD/conflicts, summer/winter transition dates, strict invalid inputs, past/open-hour/duration/alignment rules, size/media errors, CORS, active occupancy versus future reservation, linked check-in bounds/ownership, persistence/restart, separate SQLite connections and concurrent HTTP create attempts.
- Intentional demo constraints: no real auth or role security, rate limiting, audit trail, notifications, repeat reservations, waitlist, seat allocation, configurable holidays, resource CRUD, pagination, automatic occupancy expiration, migration framework or multi-host database support. These are extension points, not implemented features.
