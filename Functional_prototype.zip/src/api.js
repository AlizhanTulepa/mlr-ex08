// Shared API client. Teammates should reuse this rather than duplicate state or fetch logic.
export const DEMO_USER = 'xbatyra00';
export async function request(path, options = {}) {
  const response = await fetch(`/api${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', 'X-Demo-User': DEMO_USER, ...options.headers },
  });
  if (response.status === 204) return null;
  const data = await response.json();
  if (!response.ok) {
    const error = new Error(data.error?.message || `Request failed (${response.status})`);
    error.code = data.error?.code;
    error.status = response.status;
    throw error;
  }
  return data;
}
export const api = {
  resources: (signal) => request('/resources', { signal }),
  // excludeBookingId: when rescheduling, the server ignores this one booking (the caller's own).
  availability: (date, durationMinutes, signal, excludeBookingId) => request(`/availability?${new URLSearchParams({ date, durationMinutes, ...(excludeBookingId ? { excludeBookingId } : {}) })}`, { signal }),
  bookings: () => request('/bookings'),
  createBooking: (booking) => request('/bookings', { method: 'POST', body: JSON.stringify(booking) }),
  cancelBooking: (id) => request(`/bookings/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  rescheduleBooking: (id, times) => request(`/bookings/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(times) }),
  maintenance: (signal) => request('/maintenance', { signal }),
  createMaintenance: (block) => request('/maintenance', { method: 'POST', body: JSON.stringify(block) }),
  deleteMaintenance: (id) => request(`/maintenance/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  receptionBookings: (signal) => request('/bookings?scope=all&status=confirmed', { signal }),
  usage: (signal) => request('/usage', { signal }),
  checkIn: (session) => request('/usage/checkin', { method: 'POST', body: JSON.stringify(session) }),
  checkOut: (id) => request(`/usage/${encodeURIComponent(id)}/checkout`, { method: 'POST' }),
};
// Dispatch after any resource/booking/maintenance/usage mutation so all mounted screens refresh.
export function notifyDataChanged() { window.dispatchEvent(new Event('dormitory:data-changed')); }
