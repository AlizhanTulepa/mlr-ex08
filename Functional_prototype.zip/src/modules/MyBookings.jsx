import React, { useEffect, useRef, useState } from 'react';
import { api, DEMO_USER, notifyDataChanged } from '../api';
import { formatPragueDateTime as dateTime } from './receptionTime.mjs';
import './mybookings.css';

const TZ = 'Europe/Prague';
const DURATIONS = [30, 60, 90, 120, 150, 180];
const pragueDate = value => new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(value));
const clock = value => new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date(value));
const name = resource => resource?.name.replace(/^Demo /, '').replace(/^./, c => c.toUpperCase()) || 'Resource';
const minutes = b => Math.round((Date.parse(b.end) - Date.parse(b.start)) / 60000);
const durationLabel = n => n < 60 ? '30 minutes' : n === 60 ? '1 hour' : `${n / 60} hours`;
const reasons = { booking: 'Reserved', maintenance: 'Maintenance', past: 'Past' };
const statusOf = (b, now) => b.status === 'cancelled' ? 'cancelled'
  : Date.parse(b.end) <= now ? 'past' : Date.parse(b.start) <= now ? 'underway' : 'upcoming';
const statusLabel = { upcoming: 'Upcoming', underway: 'Underway', past: 'Past', cancelled: 'Cancelled' };

function explain(e) {
  if (e.code === 'TIME_CONFLICT') return 'That time is no longer free. The list was refreshed; choose another start time.';
  if (e.status === 404) return 'This booking no longer exists. The list was refreshed.';
  return `${e.message}${e.status === 409 ? ' The list was refreshed.' : ''}`;
}

function ReschedulePanel({ booking, disabled, saving, revision, onSave, onClose }) {
  const [date, setDate] = useState(() => pragueDate(booking.start));
  const [duration, setDuration] = useState(() => minutes(booking));
  const [slots, setSlots] = useState(null);
  const [loadError, setLoadError] = useState('');
  const [selected, setSelected] = useState(null);

  const bookingStart = Date.parse(booking.start);
  const bookingEnd = Date.parse(booking.end);
  // The server ignores this booking (excludeBookingId) but still counts every other booking and
  // all maintenance, so `available` is the final word. Slots that overlap the current time are
  // fine to pick; an unavailable slot is never selectable, whatever it overlaps.
  const kindOf = slot => {
    const s = Date.parse(slot.start), e = Date.parse(slot.end);
    if (s === bookingStart && e === bookingEnd) return 'current';
    if (!slot.available) return 'blocked';
    return s < bookingEnd && e > bookingStart ? 'overlap' : 'free';
  };

  useEffect(() => {
    if (!date) { setSlots([]); return; }
    const controller = new AbortController();
    setLoadError('');
    api.availability(date, duration, controller.signal, booking.id).then(result => {
      const list = result.resources.find(r => r.resourceId === booking.resourceId)?.slots || [];
      setSlots(list);
      setSelected(old => old && list.some(s => s.start === old.start && s.end === old.end && ['free', 'overlap'].includes(kindOf(s))) ? old : null);
    }).catch(e => { if (e.name !== 'AbortError') setLoadError(e.message); });
    return () => controller.abort();
    // kindOf only depends on the booking, which does not change while this panel is open.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date, duration, revision, booking.id, booking.resourceId]);

  const pick = (setter) => (value) => { setter(value); setSlots(null); setSelected(null); };
  const today = pragueDate(Date.now());

  return <form className="mb-panel" aria-label="Choose a new time" onSubmit={event => { event.preventDefault(); if (selected && !disabled) onSave({ start: selected.start, end: selected.end }); }}>
    <fieldset disabled={disabled}>
      <legend>Choose a new time</legend>
      <div className="mb-fields">
        <label><span>Date (Prague)</span><input type="date" required min={today} max="9999-12-31" value={date} onChange={e => pick(setDate)(e.target.value)}/></label>
        <label><span>How long?</span><select value={duration} onChange={e => pick(setDuration)(Number(e.target.value))}>{DURATIONS.map(n => <option key={n} value={n}>{durationLabel(n)}</option>)}</select></label>
      </div>
      <p className="mb-help">Each slot holds the full {durationLabel(duration)}. Your current reservation does not block its own new time.</p>
      {loadError && <p className="mb-error" role="alert">Could not load times. {loadError}</p>}
      {!slots && !loadError ? <p role="status" className="mb-help">Loading available times…</p> : <div className="mb-slots" role="group" aria-label="Start times">
        {(slots || []).map(slot => {
          const kind = kindOf(slot);
          const usable = kind === 'free' || kind === 'overlap';
          return <button type="button" key={slot.start} className={`mb-slot ${selected?.start === slot.start ? 'chosen' : ''}`} disabled={!usable} aria-pressed={selected?.start === slot.start} onClick={() => setSelected(slot)}>
            <strong>{clock(slot.start)}</strong>
            <span>{kind === 'current' ? 'Current time' : kind === 'overlap' ? 'Overlaps current' : usable ? `until ${clock(slot.end)}` : reasons[slot.reason] || 'Unavailable'}</span>
          </button>;
        })}
      </div>}
      {slots && !slots.some(s => ['free', 'overlap'].includes(kindOf(s))) && <p className="mb-empty">No other times for this date and length. Try another date or a shorter booking.</p>}
      <p className="mb-summary">{selected ? <>New time: <time dateTime={selected.start}>{dateTime(selected.start)}</time> – <time dateTime={selected.end}>{dateTime(selected.end)}</time></> : 'Select a new start time above.'}</p>
      <div className="mb-actions">
        <button type="submit" className="mb-primary" disabled={!selected}>{saving ? 'Saving…' : 'Save new time'}</button>
        <button type="button" className="mb-button" onClick={onClose}>Close</button>
      </div>
    </fieldset>
  </form>;
}

export default function MyBookings() {
  const [data, setData] = useState(null);
  const [revision, setRevision] = useState(0);
  const [fetching, setFetching] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [notice, setNotice] = useState(null);
  const [pending, setPending] = useState('');
  const [editing, setEditing] = useState('');
  const [confirming, setConfirming] = useState('');
  const [now, setNow] = useState(Date.now);
  const inFlight = useRef(false);
  const refresh = () => setRevision(v => v + 1);

  useEffect(() => {
    window.addEventListener('dormitory:data-changed', refresh);
    const timer = setInterval(refresh, 30000);
    return () => { window.removeEventListener('dormitory:data-changed', refresh); clearInterval(timer); };
  }, []);

  useEffect(() => {
    let cancelled = false;
    setFetching(true); setLoadError('');
    Promise.all([api.resources(), api.bookings()]).then(([resources, bookings]) => {
      if (cancelled) return;
      setData({ resources: resources.resources, bookings: bookings.bookings });
      setNow(Date.now());
    }).catch(e => { if (!cancelled) setLoadError(`Could not refresh your bookings. ${e.message}`); })
      .finally(() => { if (!cancelled) setFetching(false); });
    return () => { cancelled = true; };
  }, [revision]);

  const resourceName = id => name(data?.resources.find(r => r.id === id));
  const all = (data?.bookings || []).filter(b => b.userId === DEMO_USER).map(b => ({ ...b, state: statusOf(b, now) }));
  const active = all.filter(b => b.state === 'upcoming' || b.state === 'underway').sort((a, b) => a.start.localeCompare(b.start));
  const history = all.filter(b => b.state === 'past' || b.state === 'cancelled').sort((a, b) => b.start.localeCompare(a.start));
  const editingBooking = active.find(b => b.id === editing && b.state === 'upcoming');
  const initialLoading = !data && fetching;

  async function mutate(booking, key, operation, message, afterSuccess) {
    if (inFlight.current) return;
    inFlight.current = true;
    setPending(key); setNotice(null);
    try {
      await operation();
      afterSuccess?.();
      setNotice({ id: booking.id, type: 'success', text: message });
      notifyDataChanged();
    } catch (e) {
      setNotice({ id: booking.id, type: 'error', text: explain(e) });
      if (e.status === 409 || e.status === 404) refresh();
    } finally { inFlight.current = false; setPending(''); }
  }

  const cancel = booking => mutate(booking, `cancel-${booking.id}`, () => api.cancelBooking(booking.id),
    `Booking cancelled: ${resourceName(booking.resourceId)}, ${dateTime(booking.start)}. The time is free again.`, () => setConfirming(''));
  const reschedule = (booking, times) => mutate(booking, `move-${booking.id}`, () => api.rescheduleBooking(booking.id, times),
    `Booking moved to ${dateTime(times.start)}.`, () => setEditing(''));

  function renderItem(b) {
    const inlineError = notice?.type === 'error' && notice.id === b.id ? notice.text : '';
    const busy = !!pending;
    return <li key={b.id} className="mb-item">
      <div className="mb-row">
        <div>
          <span className={`mb-badge mb-${b.state}`}>{statusLabel[b.state]}</span>
          <h3>{resourceName(b.resourceId)}</h3>
          <p><time dateTime={b.start}>{dateTime(b.start)}</time> – <time dateTime={b.end}>{dateTime(b.end)}</time></p>
          <p className="mb-help">{durationLabel(minutes(b))} · Reservation {b.id}</p>
        </div>
        {b.state === 'upcoming' && <div className="mb-actions">
          <button type="button" className="mb-button" disabled={busy} aria-expanded={editing === b.id} onClick={() => { setEditing(editing === b.id ? '' : b.id); setConfirming(''); setNotice(null); }}>{editing === b.id ? 'Close' : 'Change time'}</button>
          {confirming === b.id ? <>
            <button type="button" className="mb-danger" disabled={busy} onClick={() => cancel(b)}>{pending === `cancel-${b.id}` ? 'Cancelling…' : 'Yes, cancel booking'}</button>
            <button type="button" className="mb-button" disabled={busy} onClick={() => setConfirming('')}>Keep booking</button>
          </> : <button type="button" className="mb-button" disabled={busy} onClick={() => { setConfirming(b.id); setEditing(''); setNotice(null); }}>Cancel booking</button>}
        </div>}
      </div>
      {b.state === 'underway' && <p className="mb-help">This booking has already started, so it can no longer be moved or cancelled.</p>}
      {inlineError && <p className="mb-error" role="alert">{inlineError}</p>}
      {editingBooking?.id === b.id && <ReschedulePanel booking={b} revision={revision} disabled={busy} saving={pending === `move-${b.id}`} onClose={() => setEditing('')} onSave={times => reschedule(b, times)}/>}
    </li>;
  }

  return <main className="mb">
    <div className="mb-heading"><div><p className="mb-eyebrow">Resident / My bookings</p><h1>Your reservations.</h1><p>Move a booking to another time or cancel it. A cancelled time becomes available to others immediately.</p></div><button type="button" className="mb-button" onClick={refresh} disabled={fetching || !!pending}>{initialLoading ? 'Loading…' : fetching ? 'Refreshing…' : 'Refresh data'}</button></div>
    <p className="mb-help">All times: Europe/Prague · Signed in as {DEMO_USER} (demo identity)</p>
    <div className="mb-feedback">
      {initialLoading && <p role="status">Loading your bookings…</p>}
      {loadError && <div className="mb-error" role="alert"><p>{loadError}</p><p>{data ? 'Previously loaded bookings are shown below. The server checks every change against current data.' : 'Use Retry to load your bookings.'}</p><button type="button" className="mb-button" onClick={refresh} disabled={fetching}>Retry</button></div>}
      {notice?.type === 'success' && <p className="mb-success" role="status">{notice.text}</p>}
    </div>
    {data && <>
      <section className="mb-section" aria-labelledby="mb-active-title"><h2 id="mb-active-title">Upcoming and current ({active.length})</h2>
        {active.length ? <ul className="mb-list">{active.map(renderItem)}</ul> : <p className="mb-empty">You have no upcoming reservations. Reserve a time under <a href="#availability">Availability & booking</a>.</p>}
      </section>
      <section className="mb-section" aria-labelledby="mb-history-title"><h2 id="mb-history-title">History ({history.length})</h2>
        {history.length ? <ul className="mb-list">{history.map(renderItem)}</ul> : <p className="mb-empty">Past and cancelled reservations will appear here.</p>}
      </section>
    </>}
    <footer><span>Demonstration data · the demo identity is not real authentication</span><span>Updates after changes and every 30 seconds.</span></footer>
  </main>;
}
