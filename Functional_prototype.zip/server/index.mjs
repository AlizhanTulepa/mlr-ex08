import { mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { createApp } from './app.mjs';

const serverDir=fileURLToPath(new URL('.',import.meta.url));
const dbPath=process.env.DATABASE_PATH??resolve(serverDir,'data/bookings.sqlite');
if(dbPath!==':memory:') mkdirSync(resolve(dbPath,'..'),{recursive:true});
const port=Number(process.env.PORT??3001);
if(!Number.isInteger(port)||port<0||port>65535) throw new Error('PORT must be a valid port number');
const app=createApp({dbPath,staticDir:resolve(serverDir,'../dist'),corsOrigin:process.env.CORS_ORIGIN??'http://localhost:5173'});
app.server.listen(port,process.env.HOST??'127.0.0.1',()=>console.log(`Demo booking API listening on http://${process.env.HOST??'127.0.0.1'}:${app.server.address().port}; timezone Europe/Prague; NOT production authentication`));
for(const signal of ['SIGINT','SIGTERM']) process.once(signal,()=>app.close().then(()=>process.exit(0)));
