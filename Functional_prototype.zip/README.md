# Dormitory resource booking — ITUe Phase I

React interface + asynchronous Node API + persistent SQLite. Anuar's module A:
resource overview, date/duration selection, availability, booking creation and conflict feedback.
Alizhan's module B: personal bookings, rescheduling and cancellation.
Kenzhe's module C: reception resource list, maintenance periods and actual check-in/check-out.
Resources/opening hours are fictional demonstration data, not connected to actual dormitory reception.

## Run locally

Requires Node **22.13+** (with node:sqlite), npm. Tested on Node 25.8.1.

```sh
npm ci
npm run dev
```

Open **http://127.0.0.1:5173**. API runs on 127.0.0.1:3001 through the Vite proxy.
Data persists at `server/data/bookings.sqlite` (ignored by Git).

```sh
npm run check        # deterministic API tests + production frontend build
npm run build
npm start            # serves built frontend + API at http://127.0.0.1:3001
```

No Python, external database, API keys or accounts required. SQLite uses Node's built-in driver.

## Demonstrate module A

1. Select a washer or study room, choose a future date and duration.
2. Select a free start time and click Reserve this time.
3. A saved confirmation appears; overlapping start times become unavailable without reload.
4. Refresh the page: the booking remains in SQLite.

The server rejects invalid/past times, bookings outside 07:00–22:00 Prague time,
and overlapping reservations/maintenance, including concurrent submissions.
A study room is booked as a whole, not by seat. Booking intervals are [start,end).

## Team integration

- `src/main.jsx`: Anuar's availability screen and current app entry.
- `src/modules/Reception.jsx` and `reception.css`: Kenzhe's reception screen and scoped styles.
- `src/modules/receptionTime.mjs`: Prague maintenance input conversion, including DST transitions.
- `src/api.js`: shared API client and `notifyDataChanged()` event after mutations.
- `server/`: shared HTTP/service/SQLite foundation.
- `docs/API.md`: endpoint schemas, examples, error responses and rules.
- `docs/TEAM.md`: proposed ownership and integration instructions for modules B/C.

Use **Availability & booking**, **My bookings**, and **Reception** in the shared navigation
(`#availability`, `#my-bookings`, `#reception`; browser Back/Forward works).
All three screens are implemented and stay mounted when switching.
My bookings lists current/upcoming reservations and history, supports changing time, and requires
confirmation before cancellation. Rescheduling availability excludes only the edited booking by ID;
other reservations and maintenance continue to block slots.
**Planned, not implemented:** resource editing and configurable opening hours.
Reception uses the same API and `server/data/bookings.sqlite`; no second backend/database.

## Demonstrate reception (module C)

1. Run `npm run dev`, open http://127.0.0.1:5173/#reception and choose a resource.
2. Enter a future maintenance interval and reason; click **Block maintenance time**.
   Inputs and displayed dates use **Europe/Prague**, even in a different browser timezone.
   Each displayed timestamp includes its own UTC offset, including each end of an interval.
   For example, `25 Oct 2026, 02:30 UTC+02:00` and `25 Oct 2026, 02:30 UTC+01:00`
   are different instants in the repeated autumn hour. Stored API timestamps are unchanged.
   The saved period appears with its reason and upcoming/current/past status. Reload to show persistence.
3. Switch to **Availability & booking**, select the same resource/date/duration: overlapping slots
   say **Maintenance**. A direct/concurrent overlapping booking also returns HTTP 409 `TIME_CONFLICT`.
4. In Reception, submit overlapping maintenance: the server's conflict message appears and the data
   refreshes. Confirmed bookings also prevent maintenance; they are never silently cancelled.
5. Click **Remove block**. Switch back: slots become available without a page reload, provided no
   other confirmed reservation/maintenance overlaps. Use module A to reserve the released time.
6. Under **Actual use**, click **Check in walk-in**, then **Check out**. The active session becomes
   completed usage with server timestamps. It is separate from **Current & future reservations**.
   Current maintenance disables check-in. Future maintenance does not prevent current use.
7. For a booking-linked check-in, use a confirmed reservation owned by the shared demo identity
   (`xbatyra00`) whose interval is underway. **Check in reservation** appears there; future bookings
   cannot be checked in early. Other users' reservations are visible but cannot be linked under this identity.

All successful maintenance and usage writes call `notifyDataChanged()`; both screens refresh in place.
Conflicts/missing records trigger a refresh. Reception also polls every 30 seconds and offers **Refresh data**.
Initial loading, background refresh and saving have separate feedback. Background reads preserve
draft values, focus, text selection and the ability to type. A failed background refresh keeps the
last snapshot, labels it as stale and offers **Retry**; editing and submission remain available.
Every submitted mutation is validated by the server against current data, including after a failed
read. Only saving disables the loaded form and other mutation controls, with an immediate guard
against duplicate submissions. Forms have visible labels, native keyboard
controls and focus indicators; the reception layout becomes one column on phone screens.

Maintenance uses the existing half-open `[start,end)` overlap rules. Unlike reservations, it can span
days or sit outside opening hours, including in the past. A spring DST time that does not exist is
rejected; for an autumn repeated time, choose the displayed UTC offset for start/end.

`npm run check` runs API tests, maintenance restart/persistence coverage, Prague input/display tests,
Reception and My bookings DOM regression tests (jsdom, a development-only dependency) and the
production build. For a different host timezone: `TZ=America/Los_Angeles npm test`.

The DOM regression tests simulate delayed/successful/failed 30-second polls and verify retained
draft values (including DST occurrence), focus, text selection and typing, plus Retry recovery.
They also cover the displayed repeated hour, submission after a failed read, server conflict feedback,
duplicate-submit protection and polling while a save is pending. The HTTP tests separately exercise
the real server's conflict rules.

Validation (8 November 2026): `npm run check` passes 34 tests/subtests and the production build.
The suite includes API conflict/persistence checks and DOM regressions for Reception and My bookings.
During integration, an assistant-controlled Chrome browser was used to create a reservation,
reschedule and cancel it, verify the released slot, create a maintenance block and verify blocked
availability, and record check-in/check-out. Availability was checked at desktop, 820px tablet and
390px phone widths; this is not a claim of full responsive visual testing of every screen.
The initial reception implementation's agent could not access the browser; that limitation applied
to that agent's run, not the later integration checks. These checks are not independent usability research.

## Important limitations

Educational local prototype only. `X-Demo-User` is a spoofable demo identity, **not authentication**;
reception endpoints have no real role protection. Do not expose publicly or store real resident data.
Current physical occupancy is tracked separately through usage sessions, not inferred from future slots.
No payments, hardware connection, production capacity policy or clinical/official campus claims.
UI refreshes after mutations and polls every 30 seconds; no WebSockets.

## Submission

All three Phase I modules (A/B/C) are integrated. Submit the shared six-page design report
and authoring-source ZIP following Moodle's exact naming and submission instructions.
The source package includes the application, API, tests and run instructions. Source archive must exclude node_modules, dist and local databases.
