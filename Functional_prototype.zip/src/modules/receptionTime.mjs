export const RECEPTION_TIME_ZONE = 'Europe/Prague';
const wallFormatter = new Intl.DateTimeFormat('en-CA', {
  timeZone: RECEPTION_TIME_ZONE, year: 'numeric', month: '2-digit', day: '2-digit',
  hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23',
});
function wallTime(instant) {
  const parts = Object.fromEntries(wallFormatter.formatToParts(new Date(instant)).map(p => [p.type, p.value]));
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}:${parts.second}`;
}

// datetime-local has no timezone. Resolve Prague wall time independently of the browser
// timezone, returning both occurrences at the autumn transition and none in spring's gap.
export function pragueInstants(value) {
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value) || Number(value.slice(0, 4)) < 1000) return [];
  const wall = Date.parse(`${value}:00Z`);
  if (!Number.isFinite(wall) || new Date(wall).toISOString().slice(0, 16) !== value) return [];
  const offsets = new Set([-86400000, 0, 86400000].map(delta => {
    const sample = wall + delta;
    return Date.parse(`${wallTime(sample)}Z`) - sample;
  }));
  return [...offsets].filter(Number.isFinite).map(offset => wall - offset)
    .filter(instant => wallTime(instant) === `${value}:00`)
    .sort((a, b) => a - b).map(instant => new Date(instant).toISOString());
}

export function pragueOffset(instant) {
  return new Intl.DateTimeFormat('en-GB', { timeZone: RECEPTION_TIME_ZONE, timeZoneName: 'longOffset' })
    .formatToParts(new Date(instant)).find(p => p.type === 'timeZoneName').value.replace(/^GMT/, 'UTC');
}

const dateTimeFormatter = new Intl.DateTimeFormat('en-GB', {
  timeZone: RECEPTION_TIME_ZONE, day: 'numeric', month: 'short', year: 'numeric',
  hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
});
export function formatPragueDateTime(instant) {
  return `${dateTimeFormatter.format(new Date(instant))} ${pragueOffset(instant)}`;
}
