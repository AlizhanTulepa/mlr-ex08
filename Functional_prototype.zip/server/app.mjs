import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve,extname,sep } from 'node:path';
import { createService } from './service.mjs';
import { ApiError,fail } from './time.mjs';
const MAX_BODY=16*1024;
const TYPES={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon','.json':'application/json','.woff2':'font/woff2'};
async function body(req) {
  if(!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type']??'')) fail(415,'UNSUPPORTED_MEDIA_TYPE','Use Content-Type: application/json');
  let size=0;const chunks=[];
  for await(const chunk of req) {size+=chunk.length;if(size>MAX_BODY) fail(413,'BODY_TOO_LARGE','JSON body limit is 16 KiB');chunks.push(chunk);}
  try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{fail(400,'INVALID_JSON','Request body is not valid JSON');}
}
export function createApp({dbPath=':memory:',now,staticDir,corsOrigin='http://localhost:5173'}={}) {
  const service=createService({dbPath,now});
  const server=http.createServer(async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('Cache-Control','no-store');
    const origin=req.headers.origin;
    if(origin===corsOrigin) {res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Content-Type, X-Demo-User');res.setHeader('Access-Control-Allow-Methods','GET, POST, PATCH, DELETE, OPTIONS');}
    const json=(status,value)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(value));};
    try {
      const url=new URL(req.url,'http://localhost'),path=url.pathname,method=req.method,q=Object.fromEntries(url.searchParams);
      if(method==='OPTIONS') {res.writeHead(204);res.end();return;}
      const user=req.headers['x-demo-user']??'xbatyra00';
      if(typeof user!=='string'||!/^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,63}$/.test(user)) fail(400,'INVALID_DEMO_USER','X-Demo-User must be 1–64 letters, digits, dots, underscores or hyphens');
      if(path==='/api/health'&&method==='GET') return json(200,{status:'ok',demo:true});
      if(path==='/api/resources'&&method==='GET') return json(200,service.resources());
      if(path==='/api/availability'&&method==='GET') return json(200,service.availability(q,user));
      if(path==='/api/bookings') {
        if(method==='GET') return json(200,service.bookings(user,q));
        if(method==='POST') return json(201,service.createBooking(await body(req),user));
      }
      let m=path.match(/^\/api\/bookings\/([^/]+)$/);
      if(m) {
        if(method==='PATCH') return json(200,service.reschedule(m[1],await body(req),user));
        if(method==='DELETE') return json(200,service.cancel(m[1],user));
      }
      if(path==='/api/maintenance') {
        if(method==='GET') return json(200,service.maintenance(q));
        if(method==='POST') return json(201,service.createMaintenance(await body(req)));
      }
      m=path.match(/^\/api\/maintenance\/([^/]+)$/);
      if(m) {
        if(method==='PATCH') return json(200,service.updateMaintenance(m[1],await body(req)));
        if(method==='DELETE') {service.deleteMaintenance(m[1]);res.writeHead(204);return res.end();}
      }
      if(path==='/api/usage'&&method==='GET') return json(200,service.usage(q));
      if(path==='/api/usage/checkin'&&method==='POST') return json(201,service.checkIn(await body(req),user));
      m=path.match(/^\/api\/usage\/([^/]+)\/checkout$/);
      if(m&&method==='POST') return json(200,service.checkOut(m[1]));
      if(!path.startsWith('/api/')&&staticDir&&['GET','HEAD'].includes(method)) {
        const root=resolve(staticDir),file=resolve(root,`.${decodeURIComponent(path)}`);
        if(file!==root&&!file.startsWith(root+sep)) fail(404,'NOT_FOUND','Not found');
        let data,target=file;
        try {data=await readFile(file);} catch(e) {
          if(!['ENOENT','EISDIR','ENOTDIR'].includes(e.code)) throw e;
          if(extname(path)) fail(404,'NOT_FOUND','Static file not found');
          target=resolve(root,'index.html');try{data=await readFile(target);}catch{fail(404,'NOT_FOUND','Frontend build not found; build the frontend first');}
        }
        res.writeHead(200,{'Content-Type':TYPES[extname(target)]??'application/octet-stream'});return res.end(method==='HEAD'?undefined:data);
      }
      fail(404,'NOT_FOUND','Route not found');
    } catch(e) {
      if(res.headersSent) {res.end();return;}
      if(e instanceof ApiError) return json(e.status,{error:{code:e.code,message:e.message}});
      if(e.code==='SQLITE_BUSY'||e.errcode===5) return json(503,{error:{code:'DATABASE_BUSY',message:'Database busy; retry shortly'}});
      console.error(e);
      json(500,{error:{code:'INTERNAL_ERROR',message:'Unexpected server error'}});
    }
  });
  server.requestTimeout=15_000;server.headersTimeout=10_000;
  return {server,service,async close(){if(server.listening) await new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()));service.close();}};
}
