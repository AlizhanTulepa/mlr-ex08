import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import React, { act } from 'react';
import { JSDOM } from 'jsdom';
import { build } from 'vite';

test('My bookings lists, moves and cancels reservations without duplicate submissions', async t => {
  // Compile the real component with the existing Vite toolchain; no browser is required.
  const project = fileURLToPath(new URL('../../', import.meta.url));
  const compiled = await mkdtemp(resolve(project, 'node_modules/.mybookings-test-'));
  let root, dom;
  const previousGlobals = new Map();
  t.after(async () => {
    if (root) await act(() => root.unmount());
    dom?.window.close();
    for (const [key, descriptor] of previousGlobals) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else delete globalThis[key];
    }
    await rm(compiled, { recursive: true, force: true });
  });
  const previousNodeEnv = process.env.NODE_ENV;
  try { await build({
    configFile: false, root: project, logLevel: 'silent',
    build: {
      outDir: compiled, emptyOutDir: false,
      lib: { entry: resolve(project, 'src/modules/MyBookings.jsx'), formats: ['es'], fileName: () => 'MyBookings.mjs' },
      rollupOptions: { external: ['react'] },
    },
  }); } finally {
    // Vite defaults NODE_ENV to production; React and its renderer must share test mode.
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
  dom = new JSDOM('<div id="root"></div>', { url: 'http://localhost/#my-bookings' });
  for (const [key, value] of Object.entries({
    window: dom.window, document: dom.window.document, HTMLElement: dom.window.HTMLElement,
    Event: dom.window.Event, Node: dom.window.Node, IS_REACT_ACT_ENVIRONMENT: true,
  })) {
    previousGlobals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, { value, configurable: true, writable: true });
  }
  const { createRoot } = await import('react-dom/client');
  const { default: MyBookings } = await import(pathToFileURL(resolve(compiled, 'MyBookings.mjs')));
  root = createRoot(document.getElementById('root'));

  // Data (all fixed future dates in winter, so Prague is UTC+01:00).
  const resources = ['washer-1', 'washer-2'].map((id, i) => ({ id, name: `Demo washer ${i + 1}`, type: 'washer' }));
  const own = (id, resourceId, start, end, status = 'confirmed') => ({ id, resourceId, userId: 'xbatyra00', start, end, status });
  let bookings = [
    own('b-move', 'washer-1', '2030-01-15T09:00:00.000Z', '2030-01-15T10:00:00.000Z'),
    own('b-cancel', 'washer-1', '2030-01-16T08:00:00.000Z', '2030-01-16T09:00:00.000Z'),
    own('b-live', 'washer-2', new Date(Date.now() - 30 * 60000).toISOString(), new Date(Date.now() + 30 * 60000).toISOString()),
    own('b-old', 'washer-1', '2020-01-10T09:00:00.000Z', '2020-01-10T10:00:00.000Z'),
    own('b-gone', 'washer-1', '2030-02-01T09:00:00.000Z', '2030-02-01T10:00:00.000Z', 'cancelled'),
    { ...own('b-other', 'washer-1', '2030-01-20T09:00:00.000Z', '2030-01-20T10:00:00.000Z'), userId: 'someone-else' },
  ];
  const slotAt = (date, hour, available, reason = null) => ({
    start: `${date}T${String(hour).padStart(2, '0')}:00:00+01:00`,
    end: `${date}T${String(hour + 1).padStart(2, '0')}:00:00+01:00`, available, reason,
  });
  const halfHour = (date, hour, available) => ({ start: `${date}T${hour}:30:00+01:00`, end: `${date}T${hour + 1}:30:00+01:00`, available, reason: available ? null : 'booking' });
  const span = (date, start, end, available, reason = null) => ({ start: `${date}T${start}:00+01:00`, end: `${date}T${end}:00+01:00`, available, reason });
  const bodyFor = path => {
    if (path === '/api/resources') return { resources, policy: { opensAt: '07:00', closesAt: '22:00' } };
    if (path === '/api/bookings') return { bookings: structuredClone(bookings) };
    if (path.startsWith('/api/availability?')) {
      const params = new URLSearchParams(path.split('?')[1]);
      const date = params.get('date'), duration = Number(params.get('durationMinutes'));
      // Like the server: the booking being moved is ignored, everything else still blocks.
      assert.equal(params.get('excludeBookingId'), 'b-move', 'Rescheduling asks the server to ignore the booking being moved');
      // World: this resident's booking 10:00–11:00 on washer-1, another resident's booking 09:00–10:00 right before it.
      const washer1 = duration === 90 ? [
        span(date, '08:00', '09:30', false, 'booking'),   // overlaps the other resident's booking
        span(date, '09:30', '11:00', false, 'booking'),   // overlaps the other booking AND the one being moved
        span(date, '10:00', '11:30', true),               // overlaps only the booking being moved
        span(date, '11:00', '12:30', true),
      ] : [
        slotAt(date, 10, true),                           // exactly the booking being moved
        halfHour(date, 10, true),                         // overlaps only the booking being moved
        slotAt(date, 11, true),
        slotAt(date, 12, false, 'maintenance'),
        slotAt(date, 13, true),
      ];
      return { date, durationMinutes: duration, resources: [
        { resourceId: 'washer-1', slots: washer1 },
        { resourceId: 'washer-2', slots: [slotAt(date, 8, true)] },
      ] };
    }
    throw new Error(`Unexpected read ${path}`);
  };
  const reads = [], writes = [];
  const json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
  t.mock.method(globalThis, 'fetch', (path, options = {}) => new Promise((resolve, reject) => {
    const request = { path, options, resolve, reject };
    // Like real fetch: an aborted request rejects and never delivers stale data.
    options.signal?.addEventListener('abort', () => {
      const index = reads.indexOf(request);
      if (index >= 0) reads.splice(index, 1);
      reject(new DOMException('Aborted', 'AbortError'));
    });
    (options.method ? writes : reads).push(request);
  }));
  let poll;
  t.mock.method(globalThis, 'setInterval', (callback, delay) => {
    assert.equal(delay, 30000);
    poll = callback;
    return 1;
  });
  t.mock.method(globalThis, 'clearInterval', () => {});
  async function finishReads(count, failed = false) {
    assert.equal(reads.length, count, `Expected ${count} pending reads, saw ${reads.map(r => r.path)}`);
    await act(async () => {
      for (const request of reads.splice(0)) {
        if (failed) request.reject(new TypeError('Background connection failed'));
        else request.resolve(json(bodyFor(request.path)));
      }
    });
  }
  const item = id => {
    const el = [...document.querySelectorAll('.mb-item')].find(li => li.textContent.includes(`Reservation ${id}`));
    assert.ok(el, `Booking ${id} is listed`);
    return el;
  };
  const button = (scope, text) => [...scope.querySelectorAll('button')].find(el => el.textContent.trim() === text);
  // Only the booking's own interval; an open panel also renders the chosen new time.
  const times = scope => [...scope.querySelector('.mb-row').querySelectorAll('time')].map(el => el.textContent);
  const slot = clock => [...document.querySelectorAll('.mb-slot')].find(el => el.querySelector('strong').textContent === clock);
  const choose = (select, value) => {
    Object.getOwnPropertyDescriptor(Object.getPrototypeOf(select), 'value').set.call(select, value);
    select.dispatchEvent(new dom.window.Event('change', { bubbles: true }));
  };
  const submit = form => form.dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
  const titles = () => [document.querySelector('#mb-active-title').textContent, document.querySelector('#mb-history-title').textContent];

  await t.test('initial loading does not show an incomplete list', async () => {
    await act(() => root.render(React.createElement(MyBookings)));
    assert.match(document.body.textContent, /Loading your bookings/);
    assert.equal(document.querySelector('.mb-section'), null);
    await finishReads(2);
    assert.deepEqual(titles(), ['Upcoming and current (3)', 'History (2)']);
  });
  await t.test('lists only own bookings with Prague times; started bookings have no actions', () => {
    assert.ok(!document.body.textContent.includes('b-other'), 'Another user\u2019s booking is not shown');
    assert.deepEqual(times(item('b-move')), ['15 Jan 2030, 10:00 UTC+01:00', '15 Jan 2030, 11:00 UTC+01:00']);
    const live = item('b-live');
    assert.match(live.textContent, /Underway/);
    assert.match(live.textContent, /already started/);
    assert.equal(live.querySelectorAll('button').length, 0);
    assert.match(item('b-gone').textContent, /Cancelled/);
    assert.match(item('b-old').textContent, /Past/);
  });
  await t.test('failed polling keeps the last snapshot; Retry recovers', async () => {
    await act(() => poll());
    await finishReads(2, true);
    assert.match(document.querySelector('[role="alert"]').textContent, /Previously loaded bookings/);
    assert.deepEqual(titles(), ['Upcoming and current (3)', 'History (2)']);
    await act(() => button(document, 'Retry').click());
    await finishReads(2);
    assert.equal(document.querySelector('[role="alert"]'), null);
  });
  await t.test('reschedule: only valid slots are selectable, a conflict keeps the panel, saving blocks duplicates', async () => {
    await act(() => button(item('b-move'), 'Change time').click());
    assert.equal(reads.length, 1);
    assert.equal(reads[0].path, '/api/availability?date=2030-01-15&durationMinutes=60&excludeBookingId=b-move');
    assert.match(document.body.textContent, /Loading available times/);
    await finishReads(1);
    assert.equal(slot('08:00'), undefined, 'Only this resource\u2019s slots are shown');
    assert.equal(slot('10:00').disabled, true);
    assert.match(slot('10:00').textContent, /Current time/);
    assert.equal(slot('10:30').disabled, false);
    assert.match(slot('10:30').textContent, /Overlaps current/);
    assert.equal(slot('11:00').disabled, false);
    assert.equal(slot('12:00').disabled, true);
    assert.match(slot('12:00').textContent, /Maintenance/);
    const form = document.querySelector('form.mb-panel');
    assert.equal(button(form, 'Save new time').disabled, true, 'Nothing selected yet');

    // Regression: a slot that overlaps the booking being moved AND another resident's booking is not selectable.
    await act(() => choose(form.querySelector('select'), '90'));
    assert.equal(reads.length, 1);
    assert.equal(reads[0].path, '/api/availability?date=2030-01-15&durationMinutes=90&excludeBookingId=b-move');
    await finishReads(1);
    assert.equal(slot('09:30').disabled, true, 'Overlaps another resident\u2019s booking as well');
    assert.match(slot('09:30').textContent, /Reserved/);
    assert.equal(slot('08:00').disabled, true);
    assert.equal(slot('10:00').disabled, false, 'Overlaps only the booking being moved');
    assert.match(slot('10:00').textContent, /Overlaps current/);
    assert.equal(slot('11:00').disabled, false);
    await act(() => choose(form.querySelector('select'), '60'));
    await finishReads(1);
    assert.equal(slot('10:30').disabled, false);
    assert.equal(button(form, 'Save new time').disabled, true, 'Nothing selected yet');

    await act(() => slot('11:00').click());
    assert.match(form.querySelector('.mb-summary').textContent, /15 Jan 2030, 11:00 UTC\+01:00 – 15 Jan 2030, 12:00 UTC\+01:00/);
    await act(() => { submit(form); submit(form); });
    assert.equal(writes.length, 1, 'Repeated submit in the same render sends only one mutation');
    assert.equal(writes[0].path, '/api/bookings/b-move');
    assert.equal(writes[0].options.method, 'PATCH');
    assert.deepEqual(JSON.parse(writes[0].options.body), { start: '2030-01-15T11:00:00+01:00', end: '2030-01-15T12:00:00+01:00' });
    assert.equal(form.querySelector('fieldset').disabled, true);
    assert.equal(button(form, 'Saving…').matches(':disabled'), true);

    await act(() => poll());
    await finishReads(3); // resources, bookings and the open panel's availability
    assert.equal(form.querySelector('fieldset').disabled, true, 'A completed poll must not unlock an unfinished save');

    await act(async () => writes[0].resolve(json({ error: { code: 'TIME_CONFLICT', message: 'Time overlaps an existing booking' } }, 409)));
    assert.match(item('b-move').querySelector('[role="alert"]').textContent, /no longer free/);
    assert.ok(document.querySelector('form.mb-panel'), 'The panel stays open after a conflict');
    await finishReads(3);
    assert.equal(document.querySelector('form.mb-panel fieldset').disabled, false);
    assert.match(document.querySelector('.mb-summary').textContent, /11:00 UTC\+01:00/, 'The still-free choice is kept');
    assert.deepEqual(times(item('b-move')), ['15 Jan 2030, 10:00 UTC+01:00', '15 Jan 2030, 11:00 UTC+01:00'], 'A rejected move leaves the booking unchanged');

    await act(() => submit(document.querySelector('form.mb-panel')));
    assert.equal(writes.length, 2, 'A completed failed save can be retried');
    bookings = bookings.map(b => b.id === 'b-move' ? { ...b, start: '2030-01-15T10:00:00.000Z', end: '2030-01-15T11:00:00.000Z' } : b);
    await act(async () => writes[1].resolve(json({ booking: bookings.find(b => b.id === 'b-move') })));
    assert.match(document.querySelector('.mb-success').textContent, /Booking moved to 15 Jan 2030, 11:00 UTC\+01:00/);
    assert.equal(document.querySelector('form.mb-panel'), null, 'The panel closes after a successful move');
    await finishReads(2); // notifyDataChanged() refreshed the list
    assert.deepEqual(times(item('b-move')), ['15 Jan 2030, 11:00 UTC+01:00', '15 Jan 2030, 12:00 UTC+01:00']);
  });
  await t.test('cancel needs confirmation, blocks duplicate requests and moves the booking to history', async () => {
    writes.length = 0;
    await act(() => button(item('b-cancel'), 'Cancel booking').click());
    assert.ok(button(item('b-cancel'), 'Yes, cancel booking'));
    await act(() => button(item('b-cancel'), 'Keep booking').click());
    assert.equal(button(item('b-cancel'), 'Yes, cancel booking'), undefined);
    assert.equal(writes.length, 0, 'Keeping the booking sends nothing');

    await act(() => button(item('b-cancel'), 'Cancel booking').click());
    const confirm = button(item('b-cancel'), 'Yes, cancel booking');
    await act(() => { confirm.click(); confirm.click(); });
    assert.equal(writes.length, 1, 'Repeated clicks send only one cancellation');
    assert.equal(writes[0].path, '/api/bookings/b-cancel');
    assert.equal(writes[0].options.method, 'DELETE');
    assert.equal(button(item('b-cancel'), 'Cancelling…').disabled, true);
    assert.equal(button(item('b-move'), 'Change time').disabled, true, 'Other actions wait for the save');

    await act(() => poll());
    await finishReads(2);
    assert.equal(button(item('b-cancel'), 'Cancelling…').disabled, true, 'A completed poll must not unlock an unfinished save');

    bookings = bookings.map(b => b.id === 'b-cancel' ? { ...b, status: 'cancelled' } : b);
    await act(async () => writes[0].resolve(json({ booking: bookings.find(b => b.id === 'b-cancel') })));
    assert.match(document.querySelector('.mb-success').textContent, /Booking cancelled: Washer 1, 16 Jan 2030, 09:00 UTC\+01:00/);
    await finishReads(2);
    assert.deepEqual(titles(), ['Upcoming and current (2)', 'History (3)']);
    assert.match(item('b-cancel').textContent, /Cancelled/);
    assert.equal(button(item('b-cancel'), 'Cancel booking'), undefined, 'A cancelled booking has no actions');
    assert.equal(reads.length, 0);
  });
});
