# Team integration — Phase I

Integrated module ownership:
- Anuar / xbatyra00: module A, availability and booking, app shell and API client.
- Alizhan / xtulepa00: module B, My bookings screen (list, reschedule, cancel).
- Kenzhe / xaltynk00: module C, reception screen (resources, hours, maintenance and usage).

## Work without collisions

Frontend entry: `src/main.jsx`. AvailabilityPage currently contains Anuar's whole screen.
Integrated teammate components are `src/modules/MyBookings.jsx` and `src/modules/Reception.jsx`;
keep their CSS scoped with component-specific classes. Coordinate shell/navigation changes with Anuar.
Do not replace src/main.jsx wholesale or introduce a separate app/database.

Module C integration on `codex/reception`: `src/modules/Reception.jsx` with `reception.css` and
`receptionTime.mjs` (plus timezone tests). The only module A shell changes extract its existing header
into `App` and add shared hash-link navigation (`#availability`, `#reception`). AvailabilityPage's
booking behavior is retained; all three screens stay mounted to preserve form selections and receive updates.
Review these small shared-shell/API-client changes with Anuar when integrating branches.
`src/api.js` now also wraps maintenance CRUD used by the screen (list/create/delete), reception's
confirmed booking overview and usage list/check-in/check-out. Module B also extends availability with owner-checked excludeBookingId for rescheduling.

Reuse `src/api.js`: request('/path', options) adds /api and the demo-user header, parses errors.
Call `notifyDataChanged()` after a successful mutation. Availability listens for the
`dormitory:data-changed` window event and also refreshes every 30 seconds. Reception follows the same
convention, including usage writes; 409/404 mutation errors refresh its snapshot. Reception separates
initial loading, background refresh and saving. Background reads (including failures) preserve form
values, focus and editing; a failed read retains a clearly marked previous snapshot with Retry.
The server revalidates every mutation even after a failed read. Only saving disables the loaded form;
an immediate mutation guard prevents duplicate submissions before React has rendered the saving state.
For multiple simultaneous browsers, changes are eventually visible via polling; there are no WebSockets.
See API.md for the backend contract. Reception UI is implemented in the module C files above.
Displayed start/end times each include their own Europe/Prague UTC offset; stored timestamps and
server booking rules are unchanged. DOM regression tests cover polling and repeated-hour display.

## Architecture

React view -> asynchronous API client -> Node HTTP routes -> booking service -> SQLite.
All overlap and booking-policy validation belongs on the server. Frontend disabled slots are only
convenience, not the source of truth. Conflicting submissions return HTTP 409; the UI refreshes.
Intervals are half-open [start,end), so a booking can begin exactly when another one ends.
Future availability is not current occupancy. Use active usage sessions for physical occupancy.
Demo identity is NOT authentication; never deploy this service publicly with real resident data.

## Today's Phase I demonstration

1. Select a resource and a free start time. Create a booking and show persisted confirmation.
2. Try the same interval again: it is unavailable; server also rejects a concurrent attempt.
3. In My bookings (module B), reschedule and cancel the booking and show that the slot becomes free without reload.
4. In Reception (module C), block maintenance time and show it cannot be booked, then remove the
   block and show availability updates without reload. Reload Reception to demonstrate persistence.
5. Check in/out under Actual use, then compare the recorded session with future reservations.

Steps 1–2 belong to Anuar's module A; steps 4–5 are implemented by Kenzhe in module C.
Step 3 is implemented by Alizhan in module B. Resource editing and opening-hour configuration remain
planned; current hours/resources are seeded demonstration data. See README.md for the complete demo.

## Shared report

4–6 page team report per the assignment excerpt shared in the team chat:
- user needs and existing research (do not invent reception interviews);
- screen wireframes and interaction flow, implemented vs planned features;
- model/API and technology choices;
- instructions, demonstration and limits;
- individual contribution ownership.
Each student uploads the shared PDF and source archive under their own university login,
following the exact Moodle naming instructions. Do not include node_modules, dist, database files
or other generated dependency folders in the authoring-source archive. Check the real submission status.
