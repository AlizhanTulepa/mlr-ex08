import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';
import { POLICY,fail,validateDate,validateInterval,durationMinutes,pragueTimestamp } from './time.mjs';

const RESOURCES=[...Array.from({length:3},(_,i)=>({id:`washer-${i+1}`,name:`Demo washer ${i+1}`,type:'washer',description:'Fictional demonstration resource',capacity:1})),...Array.from({length:2},(_,i)=>({id:`study-room-${i+1}`,name:`Demo study room ${i+1}`,type:'study_room',description:'Fictional demonstration resource; booking reserves the whole room, not a seat',capacity:1}))];
export function createService({dbPath=':memory:',now=()=>new Date()}={}) {
  const db=new DatabaseSync(dbPath);
  db.exec(`PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; PRAGMA journal_mode=WAL;
    CREATE TABLE IF NOT EXISTS resources(id TEXT PRIMARY KEY,name TEXT NOT NULL,type TEXT NOT NULL,description TEXT NOT NULL,capacity INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS bookings(id TEXT PRIMARY KEY,resourceId TEXT NOT NULL REFERENCES resources(id),userId TEXT NOT NULL,start INTEGER NOT NULL,end INTEGER NOT NULL,status TEXT NOT NULL CHECK(status IN ('confirmed','cancelled')),createdAt TEXT NOT NULL,updatedAt TEXT NOT NULL,CHECK(end>start));
    CREATE INDEX IF NOT EXISTS booking_overlap ON bookings(resourceId,status,start,end);
    CREATE TABLE IF NOT EXISTS maintenance(id TEXT PRIMARY KEY,resourceId TEXT NOT NULL REFERENCES resources(id),start INTEGER NOT NULL,end INTEGER NOT NULL,reason TEXT NOT NULL,createdAt TEXT NOT NULL,updatedAt TEXT NOT NULL,CHECK(end>start));
    CREATE INDEX IF NOT EXISTS maintenance_overlap ON maintenance(resourceId,start,end);
    CREATE TABLE IF NOT EXISTS usage(id TEXT PRIMARY KEY,resourceId TEXT NOT NULL REFERENCES resources(id),bookingId TEXT REFERENCES bookings(id),userId TEXT NOT NULL,checkedInAt TEXT NOT NULL,checkedOutAt TEXT);
    CREATE UNIQUE INDEX IF NOT EXISTS usage_active ON usage(resourceId) WHERE checkedOutAt IS NULL;`);
  const seed=db.prepare('INSERT OR IGNORE INTO resources(id,name,type,description,capacity) VALUES(?,?,?,?,?)');
  RESOURCES.forEach(r=>seed.run(r.id,r.name,r.type,r.description,r.capacity));
  const clock=()=>{const n=+new Date(now());if(!Number.isFinite(n)) throw new Error('Injected now() must return a valid Date, timestamp or ISO string');return n;};
  const stamp=()=>new Date(clock()).toISOString();
  const serialize=r=>r?{...r,start:new Date(r.start).toISOString(),end:new Date(r.end).toISOString()}:null;
  const resource=id=>{const r=db.prepare('SELECT * FROM resources WHERE id=?').get(id);if(!r) fail(404,'RESOURCE_NOT_FOUND','Resource not found');return {...r};};
  function transaction(fn) {
    db.exec('BEGIN IMMEDIATE');
    try {const result=fn();db.exec('COMMIT');return result;} catch(e) {db.exec('ROLLBACK');throw e;}
  }
  function conflict(resourceId,start,end,{bookingId='',maintenanceId=''}={}) {
    if(db.prepare("SELECT id FROM bookings WHERE resourceId=? AND status='confirmed' AND start<? AND end>? AND id<>? LIMIT 1").get(resourceId,end,start,bookingId)) return 'booking';
    if(db.prepare('SELECT id FROM maintenance WHERE resourceId=? AND start<? AND end>? AND id<>? LIMIT 1').get(resourceId,end,start,maintenanceId)) return 'maintenance';
    return null;
  }
  const ensureFree=(id,a,b,ignore)=>{const reason=conflict(id,a,b,ignore);if(reason) fail(409,'TIME_CONFLICT',`Time overlaps an existing ${reason}`);};
  const getBooking=id=>{const r=db.prepare('SELECT * FROM bookings WHERE id=?').get(id);if(!r) fail(404,'BOOKING_NOT_FOUND','Booking not found');return r;};
  const own=(r,user)=>{if(r.userId!==user) fail(403,'NOT_OWNER','Only the booking owner may modify this booking');};
  const getMaintenance=id=>{const r=db.prepare('SELECT * FROM maintenance WHERE id=?').get(id);if(!r) fail(404,'MAINTENANCE_NOT_FOUND','Maintenance block not found');return r;};
  function object(body,allowed,required=allowed) {
    if(!body||typeof body!=='object'||Array.isArray(body)) fail(400,'INVALID_BODY','Expected a JSON object');
    for(const k of Object.keys(body)) if(!allowed.includes(k)) fail(400,'UNKNOWN_FIELD',`Unknown field: ${k}`);
    for(const k of required) if(body[k]===undefined) fail(400,'MISSING_FIELD',`Missing field: ${k}`);
    for(const k of Object.keys(body)) if(typeof body[k]!=='string'||!body[k].trim()||body[k].length>1000) fail(400,'INVALID_FIELD',`${k} must be a nonempty string of at most 1000 characters`);
  }
  return {
    db,close:()=>db.close(),resources:()=>({resources:db.prepare('SELECT * FROM resources ORDER BY type,id').all().map(r=>({...r})),policy:POLICY}),
    availability({date,resourceId,durationMinutes:duration=30,excludeBookingId},user) {
      validateDate(date);const minutes=durationMinutes(duration);if(resourceId) resource(resourceId);
      // Rescheduling: the caller's own booking must not block its new time. Only that one booking
      // (by id) is ignored; every other booking and all maintenance still count.
      if(excludeBookingId!==undefined) {
        if(typeof excludeBookingId!=='string'||!excludeBookingId.trim()) fail(400,'INVALID_BOOKING_ID','excludeBookingId must be a nonempty booking id');
        own(getBooking(excludeBookingId),user);
      }
      const current=clock();
      return {date,timeZone:POLICY.timeZone,durationMinutes:minutes,resources:RESOURCES.filter(r=>!resourceId||r.id===resourceId).map(r=>({resourceId:r.id,slots:Array.from({length:(900-minutes)/30+1},(_,i)=>{
        const start=pragueTimestamp(date,420+i*30),end=pragueTimestamp(date,420+i*30+minutes),a=Date.parse(start),b=Date.parse(end);
        const reason=a<current?'past':conflict(r.id,a,b,{bookingId:excludeBookingId});
        return {start,end,available:!reason,reason};
      })}))};
    },
    bookings(user,{scope='mine',resourceId,status}={}) {
      if(!['mine','all'].includes(scope)) fail(400,'INVALID_SCOPE','scope must be mine or all');
      if(status&&!['confirmed','cancelled'].includes(status)) fail(400,'INVALID_STATUS','status must be confirmed or cancelled');
      if(resourceId) resource(resourceId);
      return {bookings:db.prepare('SELECT * FROM bookings ORDER BY start,id').all().filter(r=>(scope==='all'||r.userId===user)&&(!resourceId||r.resourceId===resourceId)&&(!status||r.status===status)).map(serialize)};
    },
    createBooking(body,user) {object(body,['resourceId','start','end']);resource(body.resourceId);return transaction(()=>{
      const {start,end}=validateInterval(body.start,body.end,clock());ensureFree(body.resourceId,start,end);const id=randomUUID(),at=stamp();
      db.prepare("INSERT INTO bookings VALUES(?,?,?,?,?,'confirmed',?,?)").run(id,body.resourceId,user,start,end,at,at);return {booking:serialize(getBooking(id))};
    });},
    reschedule(id,body,user) {object(body,['start','end']);return transaction(()=>{
      const r=getBooking(id);own(r,user);if(r.status!=='confirmed') fail(409,'BOOKING_CANCELLED','Cancelled bookings cannot be rescheduled');
      if(r.start<clock()) fail(409,'BOOKING_STARTED','Started bookings cannot be rescheduled');
      const {start,end}=validateInterval(body.start,body.end,clock());ensureFree(r.resourceId,start,end,{bookingId:id});
      db.prepare('UPDATE bookings SET start=?,end=?,updatedAt=? WHERE id=?').run(start,end,stamp(),id);return {booking:serialize(getBooking(id))};
    });},
    cancel(id,user) {return transaction(()=>{const r=getBooking(id);own(r,user);
      if(r.status==='confirmed'&&r.start<clock()) fail(409,'BOOKING_STARTED','Started bookings cannot be cancelled');
      db.prepare("UPDATE bookings SET status='cancelled',updatedAt=? WHERE id=?").run(stamp(),id);return {booking:serialize(getBooking(id))};
    });},
    maintenance({resourceId}={}) {if(resourceId) resource(resourceId);return {maintenance:db.prepare('SELECT * FROM maintenance ORDER BY start,id').all().filter(r=>!resourceId||r.resourceId===resourceId).map(serialize)};},
    createMaintenance(body) {object(body,['resourceId','start','end','reason']);resource(body.resourceId);return transaction(()=>{
      const {start,end}=validateInterval(body.start,body.end,clock(),{booking:false});ensureFree(body.resourceId,start,end);const id=randomUUID(),at=stamp();
      db.prepare('INSERT INTO maintenance VALUES(?,?,?,?,?,?,?)').run(id,body.resourceId,start,end,body.reason,at,at);return {maintenance:serialize(getMaintenance(id))};
    });},
    updateMaintenance(id,body) {object(body,['resourceId','start','end','reason'],[]);return transaction(()=>{
      const r=getMaintenance(id),next={...r,...body};resource(next.resourceId);
      const {start,end}=validateInterval(body.start??new Date(r.start).toISOString(),body.end??new Date(r.end).toISOString(),clock(),{booking:false});ensureFree(next.resourceId,start,end,{maintenanceId:id});
      db.prepare('UPDATE maintenance SET resourceId=?,start=?,end=?,reason=?,updatedAt=? WHERE id=?').run(next.resourceId,start,end,next.reason,stamp(),id);return {maintenance:serialize(getMaintenance(id))};
    });},
    deleteMaintenance(id) {return transaction(()=>{getMaintenance(id);db.prepare('DELETE FROM maintenance WHERE id=?').run(id);});},
    usage({resourceId,active}={}) {if(resourceId) resource(resourceId);if(active!==undefined&&!['true','false'].includes(active)) fail(400,'INVALID_ACTIVE','active must be true or false');return {usage:db.prepare('SELECT * FROM usage ORDER BY checkedInAt,id').all().filter(r=>(!resourceId||r.resourceId===resourceId)&&(active===undefined||(active==='true')===!r.checkedOutAt)).map(r=>({...r}))};},
    checkIn(body,user) {object(body,['resourceId','bookingId'],['resourceId']);resource(body.resourceId);return transaction(()=>{
      if(db.prepare('SELECT id FROM usage WHERE resourceId=? AND checkedOutAt IS NULL').get(body.resourceId)) fail(409,'ALREADY_OCCUPIED','Resource already has an active usage session');
      const current=clock();
      if(db.prepare('SELECT id FROM maintenance WHERE resourceId=? AND start<=? AND end>?').get(body.resourceId,current,current)) fail(409,'UNDER_MAINTENANCE','Resource is currently under maintenance');
      if(body.bookingId) {const r=getBooking(body.bookingId);own(r,user);if(r.resourceId!==body.resourceId||r.status!=='confirmed'||r.start>current||r.end<=current) fail(409,'INVALID_CHECK_IN','Booking must be confirmed for this resource and current time');}
      const id=randomUUID();db.prepare('INSERT INTO usage VALUES(?,?,?,?,?,NULL)').run(id,body.resourceId,body.bookingId??null,user,stamp());return {usage:{...db.prepare('SELECT * FROM usage WHERE id=?').get(id)}};
    });},
    checkOut(id) {return transaction(()=>{const r=db.prepare('SELECT * FROM usage WHERE id=?').get(id);if(!r) fail(404,'USAGE_NOT_FOUND','Usage session not found');if(!r.checkedOutAt) db.prepare('UPDATE usage SET checkedOutAt=? WHERE id=?').run(stamp(),id);return {usage:{...db.prepare('SELECT * FROM usage WHERE id=?').get(id)}};});}
  };
}
