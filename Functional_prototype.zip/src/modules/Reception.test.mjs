import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import React, { act } from 'react';
import { JSDOM } from 'jsdom';
import { build } from 'vite';

test('Reception keeps drafts and focus through polling, but prevents duplicate saves', async t => {
  // Compile the real component with the existing Vite toolchain; no browser is required.
  const project = fileURLToPath(new URL('../../', import.meta.url));
  const compiled = await mkdtemp(resolve(project, 'node_modules/.reception-test-'));
  let root, dom;
  const previousGlobals = new Map();
  t.after(async () => {
    if (root) await act(() => root.unmount());
    dom?.window.close();
    for (const [key, descriptor] of previousGlobals) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else delete globalThis[key];
    }
    await rm(compiled, { recursive: true, force: true });
  });
  const previousNodeEnv = process.env.NODE_ENV;
  try { await build({
    configFile: false, root: project, logLevel: 'silent',
    build: {
      outDir: compiled, emptyOutDir: false,
      lib: { entry: resolve(project, 'src/modules/Reception.jsx'), formats: ['es'], fileName: () => 'Reception.mjs' },
      rollupOptions: { external: ['react'] },
    },
  }); } finally {
    // Vite defaults NODE_ENV to production; React and its renderer must share test mode.
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
  dom = new JSDOM('<div id="root"></div>', { url: 'http://localhost/#reception' });
  for (const [key, value] of Object.entries({
    window: dom.window, document: dom.window.document, HTMLElement: dom.window.HTMLElement,
    Event: dom.window.Event, Node: dom.window.Node, IS_REACT_ACT_ENVIRONMENT: true,
  })) {
    previousGlobals.set(key, Object.getOwnPropertyDescriptor(globalThis, key));
    Object.defineProperty(globalThis, key, { value, configurable: true, writable: true });
  }
  const { createRoot } = await import('react-dom/client');
  const { default: Reception } = await import(pathToFileURL(resolve(compiled, 'Reception.mjs')));
  root = createRoot(document.getElementById('root'));

  const resources = ['washer-1', 'washer-2'].map((id, i) => ({ id, name: `Demo washer ${i + 1}`, type: 'washer' }));
  const fold = { id: 'fold', resourceId: 'washer-2', start: '2026-10-25T00:30:00.000Z', end: '2026-10-25T01:30:00.000Z', reason: 'Clock-change inspection' };
  const bodies = {
    '/api/resources': { resources, policy: { opensAt: '07:00', closesAt: '22:00' } },
    '/api/maintenance': { maintenance: [fold] },
    '/api/usage': { usage: [] },
    '/api/bookings?scope=all&status=confirmed': { bookings: [] },
  };
  const reads = [], writes = [];
  const json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
  t.mock.method(globalThis, 'fetch', (path, options = {}) => new Promise((resolve, reject) => {
    (options.method ? writes : reads).push({ path, options, resolve, reject });
  }));
  let poll;
  t.mock.method(globalThis, 'setInterval', (callback, delay) => {
    assert.equal(delay, 30000);
    poll = callback;
    return 1;
  });
  t.mock.method(globalThis, 'clearInterval', () => {});
  async function finishReads(failed = false) {
    assert.equal(reads.length, 4);
    await act(async () => {
      for (const request of reads.splice(0)) {
        if (failed) request.reject(new TypeError('Background connection failed'));
        else request.resolve(json(bodies[request.path]));
      }
    });
  }
  const field = text => {
    const label = [...document.querySelectorAll('label')].find(el => el.querySelector('span')?.textContent === text);
    assert.ok(label, `Visible label: ${text}`);
    return label.querySelector('input, select, textarea');
  };
  function enter(input, value) {
    Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input), 'value').set.call(input, value);
    input.dispatchEvent(new dom.window.Event(input.tagName === 'SELECT' ? 'change' : 'input', { bubbles: true }));
  }

  await t.test('initial loading does not show an incomplete form', async () => {
    await act(() => root.render(React.createElement(Reception)));
    assert.match(document.body.textContent, /Loading resources, maintenance and usage/);
    assert.equal(document.querySelector('form'), null);
    await finishReads();
  });
  await act(() => enter(field('Resource'), 'washer-2'));
  await t.test('rendered interval distinguishes both occurrences of 02:30', () => {
    const times = document.querySelectorAll('.reception-records time');
    assert.deepEqual([...times].map(el => el.textContent), [
      '25 Oct 2026, 02:30 UTC+02:00', '25 Oct 2026, 02:30 UTC+01:00',
    ]);
    assert.deepEqual([...times].map(el => el.dateTime), [fold.start, fold.end]);
  });
  await act(() => {
    enter(field('Start (Prague)'), '2026-10-25T02:30');
    enter(field('End (Prague)'), '2026-10-25T03:30');
    enter(field('Reason'), 'Draft inspection');
  });
  await act(() => enter(field('Start UTC offset — clock changes on this date'), '1'));
  const reason = field('Reason');
  reason.focus();
  reason.setSelectionRange(3, 8);
  function assertEditableDraft(expectedReason) {
    assert.equal(field('Resource').value, 'washer-2');
    assert.equal(field('Start (Prague)').value, '2026-10-25T02:30');
    assert.equal(field('End (Prague)').value, '2026-10-25T03:30');
    assert.equal(field('Start UTC offset — clock changes on this date').value, '1');
    assert.equal(field('Reason'), reason, 'The focused input is not remounted');
    assert.equal(reason.value, expectedReason);
    assert.equal(reason.matches(':disabled'), false);
    assert.equal(document.activeElement, reason);
  }
  await t.test('successful polling preserves draft, selection, focus and typing', async () => {
    await act(() => poll());
    assert.match(document.body.textContent, /Refreshing reception data/);
    assertEditableDraft('Draft inspection');
    assert.equal(reason.selectionStart, 3);
    assert.equal(reason.selectionEnd, 8);
    await act(() => enter(reason, 'Draft edited during refresh'));
    await finishReads();
    assertEditableDraft('Draft edited during refresh');
  });
  await t.test('failed polling keeps editing and submission available; Retry recovers', async () => {
    await act(() => poll());
    await act(() => enter(reason, 'Draft edited during failed refresh'));
    await finishReads(true);
    assert.match(document.querySelector('[role="alert"]').textContent, /Previously loaded information/);
    assertEditableDraft('Draft edited during failed refresh');
    assert.equal(document.querySelector('button[type="submit"]').matches(':disabled'), false);
    const retry = [...document.querySelectorAll('button')].find(el => el.textContent === 'Retry');
    await act(() => retry.click());
    await finishReads();
    assert.equal(document.querySelector('[role="alert"]'), null);
    assertEditableDraft('Draft edited during failed refresh');
  });
  await t.test('a stale snapshot still submits to the server; saving blocks duplicate requests', async () => {
    await act(() => poll());
    await finishReads(true);
    const form = document.querySelector('form');
    const submit = () => form.dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
    await act(() => { submit(); submit(); });
    assert.equal(writes.length, 1, 'Repeated submit in the same render sends only one mutation');
    assert.equal(writes[0].path, '/api/maintenance');
    assert.deepEqual(JSON.parse(writes[0].options.body), {
      resourceId: 'washer-2', start: '2026-10-25T01:30:00.000Z', end: '2026-10-25T02:30:00.000Z',
      reason: 'Draft edited during failed refresh',
    });
    assert.equal(reason.matches(':disabled'), true);
    await act(() => poll());
    await finishReads();
    assert.equal(reason.matches(':disabled'), true, 'A completed poll must not unlock an unfinished save');
    await act(async () => writes[0].resolve(json({ error: { code: 'TIME_CONFLICT', message: 'Time overlaps an existing booking' } }, 409)));
    assert.match(document.querySelector('[role="alert"]').textContent, /Time overlaps an existing booking/);
    assert.equal(reason.value, 'Draft edited during failed refresh');
    assert.equal(reason.matches(':disabled'), false);
    await finishReads();
    await act(() => submit());
    assert.equal(writes.length, 2, 'A completed failed save can be retried');
    await act(async () => writes[1].resolve(json({ maintenance: { ...fold, id: 'created' } }, 201)));
    assert.equal(reason.value, '');
    assert.match(document.body.textContent, /Maintenance saved for Washer 2/);
    await finishReads();
  });
});
