import test from 'node:test';
import assert from 'node:assert/strict';
import { pragueInstants, formatPragueDateTime } from './receptionTime.mjs';

test('display distinguishes both ends of an interval in the repeated Prague hour', () => {
  const start = '2026-10-25T00:30:00.000Z';
  const end = '2026-10-25T01:30:00.000Z';
  assert.equal(formatPragueDateTime(start), '25 Oct 2026, 02:30 UTC+02:00');
  assert.equal(formatPragueDateTime(end), '25 Oct 2026, 02:30 UTC+01:00');
});

test('maintenance inputs resolve Prague winter/summer times independently of host timezone', () => {
  assert.deepEqual(pragueInstants('2027-01-05T09:15'), ['2027-01-05T08:15:00.000Z']);
  assert.deepEqual(pragueInstants('2027-07-05T09:15'), ['2027-07-05T07:15:00.000Z']);
  assert.deepEqual(pragueInstants('2027-01-05T00:15'), ['2027-01-04T23:15:00.000Z']);
});

test('maintenance input detects missing and repeated Prague daylight-saving times', () => {
  assert.deepEqual(pragueInstants('2027-03-28T02:30'), []);
  assert.deepEqual(pragueInstants('2027-10-31T02:30'), ['2027-10-31T00:30:00.000Z', '2027-10-31T01:30:00.000Z']);
  assert.deepEqual(pragueInstants('2027-03-28T03:00'), ['2027-03-28T01:00:00.000Z']);
});

test('maintenance input rejects incomplete and impossible calendar dates', () => {
  for (const value of ['', '2027-02-30T10:00', '2027-01-05T25:00', '2027-1-05T10:00', '2027-01-05', '0999-01-05T10:00']) {
    assert.deepEqual(pragueInstants(value), [], value);
  }
});

test('maintenance input handles calendar bounds without throwing', () => {
  assert.equal(pragueInstants('1000-01-01T12:00').length, 1);
  assert.deepEqual(pragueInstants('9999-12-31T23:59'), ['9999-12-31T22:59:00.000Z']);
});
